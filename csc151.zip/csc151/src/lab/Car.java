package lab;

public abstract class Car implements Vehicle{
	protected double miles;
	protected String color;
	protected int doors;
	protected String make;
	protected String model;
	
	public Car(){
		miles = 0;
		color = "black";
		doors = 4;
	}
	
	public void identify(){
		System.out.println("Make: " + make);
		System.out.println("Model: " + model);
		System.out.println("Color: " + color);
		System.out.println("Miles: " + miles);
	}
	
	public double getMiles(){
		return miles;
	}
	
	public void setMiles(double miles){
		this.miles = miles;
	}
	
	public String getColor(){
		return color;
	}
	
	public void setColor(String color){
		this.color = color;
	}
	
	public int getDoors(){
		return doors;
	}
	
	public void setDoors(int doors){
		this.doors = doors;
	}
	
	public String getMake(){
		return make;
	}
	
	public void setMake(String make){
		this.make = make;
	}
	
	public String getModel(){
		return model;
	}
	
	public void setModel(String model){
		this.model = model;
	}

}
