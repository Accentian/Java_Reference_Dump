package lab;

import javax.swing.JOptionPane;

/*
Prompt user for employee�s name
Once name is entered, store name in memory (a variable)
Prompt user for number of hours employee worked
Once hours are entered, store it in memory (a variable)
Prompt user for employee�s hourly pay rate
Once rate is entered, store it in memory (a variable)
Multiply hours and pay rate and store result in memory (a variable)
Display message that informs user of the results of the calculation, e.g. gross pay.
 */


public class GrossPayCalculator {

	public static void main(String[] args) {
		
		//Get employee's name
		String name = JOptionPane.showInputDialog("Enter the employee's name");
		
		//Create temporary String variable to hold input. All input from JOptionPane is of type String by default
		String input = "";
		
		//Create a message variable
		String message = String.format("How many hours did %s work", name);
		
		//Get number of hours worked
		input = JOptionPane.showInputDialog(message);
		
		//Convert our String input into a number
		Double hours = Double.parseDouble(input);
		
		//Get pay rate
		message = String.format("How much does %s make per hour", name);
		input = JOptionPane.showInputDialog(message);
		Double rate = Double.parseDouble(input);
		
		//Calculate gross pay
		Double grossPay = hours * rate;
		
		//Format output message
		message = String.format("%s's gross pay is $%.2f", name, grossPay);
		
		JOptionPane.showMessageDialog(null, message);
		
		//Ensures the process used to run the dialog boxes is terminated
		System.exit(0);
		
		

	}

}
