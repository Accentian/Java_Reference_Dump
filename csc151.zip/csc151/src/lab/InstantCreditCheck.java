package lab;

import javax.swing.JOptionPane;

/*
 * Write an ‘instant credit check’ program that approves anyone who makes more than 
 * $25,000 and has a credit score of 700 or better. Reject all others.
 *
 */

public class InstantCreditCheck {

	//Global variables
	static double salary = 0;
	static int creditScore = 0;
	
	public static void getFormData(){
		String input = JOptionPane.showInputDialog("Enter your salary");
		salary = Double.parseDouble(input);
		
		input = JOptionPane.showInputDialog("Enter your credit score");
		creditScore = Integer.parseInt(input);
		
	}
	public static boolean isUserQualified(){
		if(salary > 25000 && creditScore >= 700){
			return true;
		}
		else{
			return false;
		}
		
	}
	public static void notifyUser(boolean isQualified){
		if(isQualified){
			JOptionPane.showMessageDialog(null, "Congrats! You've been approved!");
		}else{
			JOptionPane.showMessageDialog(null, "Sorry, You've been declined");
		}
	}
	
	//Let your main method drive your program by making calls to the other methods
	public static void main(String[] args) {
		
		getFormData();
		boolean isQualified = isUserQualified();
		notifyUser(isQualified);
		
		System.exit(0);
	}

}
