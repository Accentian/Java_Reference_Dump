package lab;

public class Coupe extends Car{
	
	public Coupe(){
		doors = 2;
	}

	public void move() {
		System.out.println("vroom vroom");
	}

}
