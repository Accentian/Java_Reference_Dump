package lab;

import javax.swing.JOptionPane;

public class HomeAreaCalculatorRedo {

	public static void main(String[] args) {
		Rectangle kitchen = getRoom();
		Rectangle bathroom = getRoom();
		
		double area = calculateTotalArea(kitchen, bathroom);
		
		String message = String.format("The total area of the rooms is %.2f", area);
		JOptionPane.showMessageDialog(null, message);
		System.exit(0);
	}
	
	public static Rectangle getRoom(){
		//Get input
		String input = JOptionPane.showInputDialog("Enter the length of your room.");
		double length = Double.parseDouble(input);
		
		input = JOptionPane.showInputDialog("Enter the width of your room.");
		double width = Double.parseDouble(input);
		
		//Create instance of Rectangle
		Rectangle room = new Rectangle(length, width);
		return room;
	}
	
	/**
	 * Calculate area of two rooms
	 * @param r1 first room
	 * @param r2 second room
	 * @return
	 */
	public static double calculateTotalArea(Rectangle r1, Rectangle r2){
		return r1.calculateArea() + r2.calculateArea();
	}

}
