package lab;

public class LoanApplication {

	private Applicant person;
	
	public LoanApplication(Applicant person){
		this.person = person;
	}

	public boolean isApproved(){
		double salary = person.getIncome();
		int years = person.getYearsEmployed();
		
		if(salary >= 50000 && years >= 5){
			return true;
		}
		else{
			return false;
		}
	}
}