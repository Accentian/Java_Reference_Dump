package lab;

public class Hat extends Garment{
	
	public Hat(String name, String desc, String color, double price){
		this.name = name;
		this.desc = desc;
		this.color = color;
		this.price = price;
		setSize("One size");
	}
	
	public void setSize(String size){
		this.size = size;
	}
	
	String setSize() {
		return size;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
}
