package lab;


import javax.swing.JOptionPane;

public class Sum {

	/**
	 * Adds two numbers
	 * @param num1 first number to add
	 * @param num2 second number to add
	 * @return sum of the numbers
	 */
	public static double add(double num1, double num2){
		double sum = num1 + num2;
		return sum;
	}
	
	
	public static void main(String[] args) {
		
		String input = JOptionPane.showInputDialog("Enter the first number");
		double number1 = Double.parseDouble(input);
		
		input = JOptionPane.showInputDialog("Enter the second number");
		double number2 = Double.parseDouble(input);
		
		//Call method and store return value into a variable
		double result = add(number1, number2);
		
		String message = String.format("The sum is %.2f", result);
		System.out.println(message);
		
		System.exit(0);
	}
	

}
