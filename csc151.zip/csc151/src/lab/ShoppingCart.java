package lab;

import java.util.ArrayList;

public class ShoppingCart {

	public static void main(String[] args) {
		
		ArrayList<Product3> products = getProducts();
		printReceipt(products);
	}
	
	public static ArrayList<Product3> getProducts(){
		
		ArrayList<Product3> items = new ArrayList<Product3>();
		
		items.add(new Product3("soap", 8.99));
		items.add(new Product3("coffee", 7.99));
		items.add(new Product3("chips", 3.99));
		
		return items;		
	}
	
	public static double getSubtotal(ArrayList<Product3> products){
		double subtotal = 0;
		for(Product3 product : products){
			subtotal = subtotal + product.getCost();
		}
		return subtotal;
	}
	
	public static void printReceipt(ArrayList<Product3> products){
		System.out.println("RECEIPT");
		System.out.println("=======================");
		
		for(Product3 product : products){
			String message = String.format("%s\t\t$%.2f", product.getName(), product.getCost());
			System.out.println(message);
		}
		
		String message = String.format("\nTOTAL\t\t$%.2f", getSubtotal(products));
		System.out.println(message);
		
	}

}
