package lab;

import javax.swing.JOptionPane;

public class PasswordChanger {

	public static void main(String[] args) {
		String input = JOptionPane.showInputDialog("Your password must have at least 8 characters, at least 1 uppercase letter, at least 1 lowercase letter, and at least one special character.");
		
		boolean valid = true;
		
		if(!containsUppercase(input)){
			valid = false;
			JOptionPane.showMessageDialog(null, "Your password must contain an uppercase letter.");
		}
		
		if(!containsLowercase(input)){
			valid = false;
			JOptionPane.showMessageDialog(null, "Your password must contain an lowercase letter.");
		}
		
		if(!containsSpecialChar(input)){
			valid = false;
			JOptionPane.showMessageDialog(null, "Your password must contain a special character.");
		}
		
		if(!isLengthValid(input)){
			valid = false;
			JOptionPane.showMessageDialog(null, "Your password must contain at least 8 character.");
		}
		
		if(valid){
			JOptionPane.showMessageDialog(null, "Your password is valid.");
		}
		
		}

	private static boolean containsUppercase(String input) {
		boolean isValid = false;
		for(int i=0; i<input.length(); i++){
			if(Character.isUpperCase(input.charAt(i))){
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	private static boolean containsLowercase(String input) {
		boolean isValid = false;
		for(int i=0; i<input.length(); i++){
			if(Character.isLowerCase(input.charAt(i))){
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	private static boolean containsSpecialChar(String input) {
		boolean isValid = false;
		for(int i=0; i<input.length(); i++){
			if(!Character.isLetterOrDigit(input.charAt(i))){
				isValid = true;
				break;
			}
		}
		return isValid;
	}
	
	private static boolean isLengthValid(String input) {
		return input.length() >= 8;
	}
	
}
