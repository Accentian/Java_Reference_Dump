package lab;

import javax.swing.JOptionPane;

public class Greetings {
	
	public static void main(String args[]){
		String name = JOptionPane.showInputDialog("Enter your name");
		
		//Call method
		greetUser(name);
		
		System.exit(0);
	}
	
	/**
	 * Greets user by name
	 * @param name Name to use within greeting
	 */
	public static void greetUser(String name){
		//This is similar to JOptionPane.showMessageDialog, but it writes to the console instead of a popup
		System.out.println("Hi there " + name);
	}

}
