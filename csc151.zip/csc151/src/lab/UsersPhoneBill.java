package lab;

import javax.swing.JOptionPane;

public class UsersPhoneBill {

	public static void main(String[] args) {
		PhoneBill bill = new PhoneBill();
		bill.setName("Brandon Ma");
		bill.setAccNumber("009");
		bill.setTotal(107.56);
		
		JOptionPane.showMessageDialog(null, "Name: " + bill.getName());
		JOptionPane.showMessageDialog(null, "Account Number: " + bill.getAccNumber());
		JOptionPane.showMessageDialog(null, "Total due: " + bill.getTotalDue());
	}

}
