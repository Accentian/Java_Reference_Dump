package lab;

import javax.swing.JOptionPane;

/*
 * NESTED IFS:
 * To qualify for a loan, a person must make at least $30,000 
 * and have been working at their current job for at least 2 years.

 */
public class LoanQualifier {

	public static void main(String[] args) {
		//Initialize what we know
		double requiredSalary = 30000;
		double requiredYearsEmployed = 2;
		
		//Get input for what we don't know
		String input = JOptionPane.showInputDialog("What is your salary?");
		double salary = Double.parseDouble(input);
		
		input = JOptionPane.showInputDialog("How many years have you been employed at your current job?");
		double years = Double.parseDouble(input);
		
		//Make decision
		if(salary >= requiredSalary){
			
			if(years >= requiredYearsEmployed){
				JOptionPane.showMessageDialog(null, "Congratulations! You qualify for the loan.");
			}
			else{
				JOptionPane.showMessageDialog(null, "Sorry, you must have worked at your current job at least " + requiredYearsEmployed + " years");
			}
		}
		else{
			JOptionPane.showMessageDialog(null, "Sorry, you must earn at least $" + requiredSalary + " to qualify for the loan.");
		}
		
		System.exit(0);

	}

}
