package lab;

public class Amazon {

	public static void main(String[] args) {
		Product2 book = new Book();
		Book book2 = new Book();

	}

}
