package lab;

import java.util.Scanner;

public class Grades {

	private static int grades[];

	public static void main(String[] args) {
		System.out.println("How many grades would you like to enter?");

		//Reads input from console
		Scanner keyboard = new Scanner(System.in);
		int arraySize = keyboard.nextInt();
		grades = new int[arraySize];


		for(int i=0; i<arraySize; i++){
			System.out.println("Enter grade #" + (i+1));
			grades[i] = keyboard.nextInt();
		}

		float average = getSum() / arraySize;
		String message = String.format("The average is %.1f", average);
		System.out.println(message);

		message = String.format("The lowest score is %d", getLowest());
		System.out.println(message);
		
		message = String.format("The highest is %d", getHighest());
		System.out.println(message);
		
		keyboard.close();
	}

	public static int getSum(){
		int sum = 0;
		for(int grade : grades){
			sum = sum + grade;
		}
		return sum;
	}

	public static int getLowest(){
		int lowest = grades[0];
		for(int grade : grades){
			if(grade < lowest){
				lowest = grade;
			}
		}
		return lowest;
	}

	public static int getHighest(){
		int highest = grades[0];
		for(int grade : grades){
			if(grade > highest){
				highest = grade;
			}
		}
		return highest;
	}

}
