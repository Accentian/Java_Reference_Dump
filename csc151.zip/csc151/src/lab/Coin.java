package lab;

import java.util.Random;

public class Coin {
	
	private String coinValue;
	
	public String getCoinValue(){
		return coinValue;
	}
	
	public String flip(){
		Random random = new Random();
		int randomInt = random.nextInt(2);
		
		switch(randomInt){
		case 0: coinValue =  "heads"; break;
		case 1: coinValue = "tails"; break;
		}
		
		return coinValue;
		
	}

}
