package lab;

import javax.swing.JOptionPane;

/*
 * IF ELSE:
 * All salespersons are expected to make at least 10 sales each week. 
 * For those who do, they receive a congratulatory message. 
 * For those who don�t, they are informed of how many sales they were short. 
 */
public class QuotaCalculator {

	public static void main(String[] args) {
		//Initialize variables that we do know
		int quota = 10;
		
		//Get values for the unknown variables
		String input = JOptionPane.showInputDialog("How many sales did the employee make this week?");
		int sales = Integer.parseInt(input);
		
		//Make a decision on which path to take
		if(sales >= quota){
			JOptionPane.showMessageDialog(null, "Way to go! You met your quota");
		}
		else{
			int salesShort = quota - sales;
			String output = String.format("You did not make your quota. You were %d sales short", salesShort);
			JOptionPane.showMessageDialog(null, output);
		}
		
		System.exit(0);

	}

}
