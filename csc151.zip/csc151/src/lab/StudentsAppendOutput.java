package lab;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * A new student wants to enroll in the course by the name of Lucy Lions.
 * Add her to students.txt
 */
public class StudentsAppendOutput {

	public static void main(String[] args) throws IOException {
		
		String studentToAdd = "Lions, Lucy";
		
		//Open connection to file
		File file = new File("resources/students.txt");
		
		//true for append mode
		FileWriter writer = new FileWriter(file, true);
		PrintWriter printer = new PrintWriter(writer);
		
		//Write to file
		printer.println(studentToAdd);
		
		//Close connection to file
		writer.close();
		printer.close();

	}

}
