package lab;

public abstract class Garment implements Product {
	
	abstract String setSize();
	protected String size;
	protected String name;
	protected String desc;
	protected String color;
	protected double price;
	
	public String getSize(){
		return size;
	}
	
	public void setSize(String size){
		this.size = size;
	}
	
	public void order(){
		System.out.println("Your order:");

		System.out.println("Name: " + name);

		System.out.println("Price: $" + price);

		System.out.println("Size: " + size);

		System.out.println("Color: " + color);

		System.out.println("Description: " + desc);
	}
}
