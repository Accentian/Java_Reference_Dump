package lab;

import javax.swing.JOptionPane;

public class inputWords {

	public static void main(String[] args) {
		
		String adj1 = JOptionPane.showInputDialog("Enter a adjective");
		
		String adj2 = JOptionPane.showInputDialog("Enter another adjective (2)");
		
		String adj3 = JOptionPane.showInputDialog("Enter another adjective (3)");
		
		String adj4 = JOptionPane.showInputDialog("Enter another adjective (4)");
		
		String adverb1 = JOptionPane.showInputDialog("Enter a adverb");
		
		String subjectTeacher = JOptionPane.showInputDialog("Enter a subject");
		
		String teacherName = JOptionPane.showInputDialog("Enter a name");
		
		String verb1 = JOptionPane.showInputDialog("Enter a verb");
		
		String verb2 = JOptionPane.showInputDialog("Enter another verb (2)");
		
		String message = String.format("MADLIB Today was the first day of school. I was a "
				+ "little nervous because I�d heard some %s rumors about our new %s teacher. "
				+ "Don�t get me wrong, some students thought that %s was adjective %s, "
				+ "but there were many who thought she was the %s teacher they�d ever met. "
				+ "Other students from last year told us how %s would %s to the front of the "
				+ "classroom then %s %s to get the class�s attention. Most of the time, "
				+ "%s was very unpredictable. So you see, many of us were a little %s when we "
				+ "first entered the classroom.", 
				adj1, subjectTeacher, adj2, adj3, teacherName, verb1, verb2, adverb1, adj4);
		
		JOptionPane.showMessageDialog(null, message);
		
		System.exit(0);		

	}

}
