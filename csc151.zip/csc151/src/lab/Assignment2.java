package lab;

import javax.swing.JOptionPane;

public class Assignment2 {

	public static void main(String[] args) {
		
		String xInput = JOptionPane.showInputDialog("Enter an Integer X-Coordinate.");
		int xCoord = Integer.parseInt(xInput);
		
		String yInput = JOptionPane.showInputDialog("Enter an Integer Y-Coordinate.");
		int yCoord = Integer.parseInt(yInput);
		
		
		if(xCoord > 0 && yCoord > 0){
			JOptionPane.showMessageDialog(null, "Coordinates located in Quadrant 1.");
		}
		else if(xCoord > 0 && yCoord < 0){
			JOptionPane.showMessageDialog(null, "Coordinates located in Quadrant 4.");
		}
		else if(xCoord < 0 && yCoord > 0){
			JOptionPane.showMessageDialog(null, "Coordinates located in Quadrant 2.");
		}
		else if (xCoord < 0 && yCoord < 0){
			JOptionPane.showMessageDialog(null, "Coordinates located in Quadrant 3");
		}
		else{
			JOptionPane.showMessageDialog(null, "Coordinates located on axis.");
		}
		
		System.exit(0);
	}

}
