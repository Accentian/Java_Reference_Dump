package lab;

import javax.swing.JOptionPane;

/*
 * WHILE LOOP:
 * Each store employee makes $15 an hour. Write a program that allows the employee 
 * to enter the number of hours worked for the week. Do not allow overtime.
 */
public class GrossPayInputValidation {

	public static void main(String args[]){

		//initialize known variables
		int rate = 15;

		//Get input for unknown variables
		String input = JOptionPane.showInputDialog("How many hours did you work?");
		double hours = Double.parseDouble(input);

		//Use loop to validate input
		while(hours > 40 || hours <= 0){
			input = JOptionPane.showInputDialog("Invalid entry. Your hours must be between 1 and 40. Try again.");
			hours = Double.parseDouble(input); //this is the sentinel
		}
		
		//Calculate gross
		double gross = rate * hours;
		JOptionPane.showMessageDialog(null, "Gross $" + gross);
		
		System.exit(0);
	}
}
