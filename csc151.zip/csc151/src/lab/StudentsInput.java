package lab;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JOptionPane;

/*
 * Write a program that allows a user to search to see if a name exists in the file.
 */
public class StudentsInput {

	public static void main(String[] args) throws FileNotFoundException {
		
		//Ask use for name to search for
		String nameToSearchFor = JOptionPane.showInputDialog("Enter a name to search for");
		
		//Create a variable to track whether we found name or not
		boolean found = false;
		
		//Create file object
		File file = new File("resources/students.txt");
		
		//Create an object to read the file
		Scanner fileReader = new Scanner(file);
		
		while(fileReader.hasNext()){
			String name = fileReader.nextLine();
			if(nameToSearchFor.equalsIgnoreCase(name)){
				found = true;
				break;
			}
		}
		
		//Close connection to file
		fileReader.close();
		
		
		if(found){
			JOptionPane.showMessageDialog(null, nameToSearchFor + " is in CSC 151");
		}
		else{
			JOptionPane.showMessageDialog(null, nameToSearchFor + " is not in CSC 151");
		}

		System.exit(0);
	}

}
