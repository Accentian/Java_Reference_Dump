package lab;

public interface Product {
	
	double getPrice();
	void setPrice(double price);
	
	String getName();
	void setName(String name);
	
	String getDesc();
	void setDesc(String desc);
	
	String getColor();
	void setColor(String color);

}
