package lab;

import javax.swing.JOptionPane;

/*
 * NESTED LOOPS:
 * Find the average of each student's test scores
 */
public class AverageTestScores {

	public static void main(String[] args) {
		
			
		String input = JOptionPane.showInputDialog("How many students do you have?");
		int numberOfStudents = Integer.parseInt(input);
		
		input = JOptionPane.showInputDialog("How many test scores are there per student?");
		int numberOfTests = Integer.parseInt(input);
		
		//Process all students
		for(int i=0; i < numberOfStudents; i++){
			
			//Reset accumulator to 0 before starting on each student
			double total = 0;
			
			//Process this student's tests
			for(int j=0; j < numberOfTests; j++){
				input = JOptionPane.showInputDialog("Enter the score for test " + (j+1));
				double score = Double.parseDouble(input);
				total = total + score;
			}
			
			//Calculate and display the average
			double average = total/numberOfTests;
			String message = String.format("The test average for student %d is %.2f", (i+1), average);
			JOptionPane.showMessageDialog(null, message);
		}
		
		System.exit(0);

	}

}
