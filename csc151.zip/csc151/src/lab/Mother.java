package lab;

public class Mother extends Woman{

	public Mother(String name) {
		super(name);
	}

}
