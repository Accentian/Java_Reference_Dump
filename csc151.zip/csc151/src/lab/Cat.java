package lab;

public class Cat extends Animal{

	public void makeSound(){
		System.out.println("meow");
	}
	
	public void scratch(){
		System.out.println("I am a mean cat. I scratch things");
	}
}
