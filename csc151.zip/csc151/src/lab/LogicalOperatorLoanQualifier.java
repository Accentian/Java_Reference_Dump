package lab;

import javax.swing.JOptionPane;

/*
 * LOGICAL OPERATOR PROBLEM:
 * To qualify for a loan, a person must make at least $30,000 
 * and have been working at their current job for at least 2 years.
 */
public class LogicalOperatorLoanQualifier {

	public static void main(String args[]){
		//Initialize what we know
		double requiredSalary = 30000;
		double requiredYearsEmployed = 2;
		
		//Get input for what we don't
		String input = JOptionPane.showInputDialog("What is your salary?");
		double salary = Double.parseDouble(input);
		
		input = JOptionPane.showInputDialog("How many years have you been working at your current job?");
		double yearsEmployed = Double.parseDouble(input);
		
		//Use logical operator to check both conditions
		if(salary >= requiredSalary && yearsEmployed >= requiredYearsEmployed){
			JOptionPane.showMessageDialog(null, "Congratulations, you qualify for the loan.");
		}
		else{
			JOptionPane.showMessageDialog(null, "Sorry, you do not qualify for the loan.");
		}
		
		System.exit(0);
	}

}
