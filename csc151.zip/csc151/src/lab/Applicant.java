package lab;

public class Applicant {
	
	private String name;
	private double income;
	private int yearsEmployed;
	
	public Applicant(){
		name = "";
		income = 0;
		yearsEmployed = 0;
		
	}
	
	public Applicant(String userName, Double incomeValidation, int yearsValidation) {
		this.name = userName;
		this.income = incomeValidation;
		this.yearsEmployed = yearsValidation;
	}

	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public double getIncome(){
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}
	
	public int getYearsEmployed(){
		return yearsEmployed;
	}
	
	public void setYearsEmployed(int yearsEmployed){
		this.yearsEmployed = yearsEmployed;
	}
}