package lab;

public class PhoneBill {
	
	private String name;
	private String accNumber;
	private double totalDue;

	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getAccNumber(){
		return accNumber;
	}
	
	public void setAccNumber(String accNumber){
		this.accNumber = accNumber;
	}
	
	public PhoneBill(){
		totalDue = 0;
	}
	
	public PhoneBill(double totalDue){
		this.totalDue = totalDue;
	}
	
	public double getTotalDue(){
		return totalDue;
	}
	
	public void setTotal(double totalDue){
		this.totalDue = totalDue;
	}
	

}
