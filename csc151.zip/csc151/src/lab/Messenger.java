package lab;

import javax.swing.JOptionPane;

public class Messenger {

	public static void main(String[] args) {
		
		String name = JOptionPane.showInputDialog("Enter your name.");
		
		String input = JOptionPane.showInputDialog("Enter your income.");
		Double income = Double.parseDouble(input);
		
		Double incomeValidation = usersIncomeValidation(income);
		
		input = JOptionPane.showInputDialog("Enter the amount of years you worked.");
		int years = Integer.parseInt(input);
		
		int yearsValidation = usersYearsValidation(years);
		
		Applicant applicant = new Applicant(name, incomeValidation, yearsValidation);
		
		LoanApplication application = new LoanApplication(applicant);
		
		if(application.isApproved()){
			String message = String.format("Congratulations %s, you are qualified for a loan.", name);
			JOptionPane.showMessageDialog(null, message);
		}
		else{
			String message = String.format("Sorry, %s, you are not qualified for a loan.", name);
			JOptionPane.showMessageDialog(null, message);
		}
	}

	public static double usersIncomeValidation(Double income){
		while(income < 0){
			String incomeError = JOptionPane.showInputDialog("Invalid input. Please try again.");
			income = Double.parseDouble(incomeError);
		}
		return income;
	}
	
	public static int usersYearsValidation(int years){
		while(years < 0 || years > 100){
			String yearsError = JOptionPane.showInputDialog("Invalid input. Please enter a number between 0 - 100.");
			years = Integer.parseInt(yearsError);
		}
		return years;
	}

}
