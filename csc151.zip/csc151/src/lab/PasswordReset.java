package lab;

import java.util.Scanner;

public class PasswordReset {

	public static void main(String[] args) {
		System.out.println("Enter your new password");
		Scanner keyboard = new Scanner(System.in);
		String password = keyboard.nextLine();
		boolean valid = true;

		if(!containsUppercase(password)){
			valid = false;
			System.out.println("Your password must contain an uppercase letter");
		}
		if(!containsLowerCase(password)){
			valid = false;
			System.out.println("Your password must contain an lowercase letter");
		}
		if(!containsSpecialChar(password)){
			valid = false;
			System.out.println("Your password must contain a special character");
		}
		if(!isLengthValid(password)){
			valid = false;
			System.out.println("Your password must be at least 8 characters");
		}
		if(valid){
			System.out.println("Your password is valid");
		}


	}

	private static boolean containsUppercase(String pwd){
		boolean isValid = false;
		for(int i=0; i<pwd.length(); i++){
			if(Character.isUpperCase(pwd.charAt(i))){
				isValid = true;
				break;
			}
		}
		return isValid;
	}

	private static boolean containsLowerCase(String password) {
		// TODO Auto-generated method stub
		return false;
	}


	private static boolean isLengthValid(String password) {
		return password.length() >= 8;
	}

	private static boolean containsSpecialChar(String password) {
		// TODO Auto-generated method stub
		return false;
	}



}
