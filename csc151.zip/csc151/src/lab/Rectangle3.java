package lab;

public class Rectangle3 extends Shape{

	private double length;
	private double width;
	
	public Rectangle3(double l, double w){
		length = l;
		width = w;
	}
	
	
	@Override
	public double calculateArea() {
		return length * width;
	}

}
