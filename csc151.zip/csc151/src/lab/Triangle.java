package lab;

public abstract class Triangle extends Shape{

}
