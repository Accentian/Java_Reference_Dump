package lab;

import javax.swing.JOptionPane;

public class BirthdayCake extends Cake{
	
	protected int candles;
	
	public BirthdayCake(){
		super("Vanilla");
	}
	
	public int getCandles(){
		return candles;
	}
	
	public void setCandles(int candles){
		this.candles = candles;
	}
	
	public void showMessage(){
		String message = String.format("Thank you for the purchased of %s birthday cake, with %d candles.", flavor, candles);
		JOptionPane.showConfirmDialog(null, message);
		
	}

}
