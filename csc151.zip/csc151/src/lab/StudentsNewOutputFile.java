package lab;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

/*
 * Make a new file and allow a user to enter the student names to go into the file
 */
public class StudentsNewOutputFile {

	public static void main(String[] args) throws IOException {
		
		//Open connection to file that doesn't exist
		File file = new File("resources/newstudents.txt");
		file.createNewFile();
		
		//This class has a method to print as a line
		PrintWriter printWriter = new PrintWriter(file);
		
		//Sentinel
		int addAnother = JOptionPane.NO_OPTION;
		
		do{
			String name = JOptionPane.showInputDialog("Enter a name");
			printWriter.println(name);
			
			//Potentially updating sentinel
			addAnother = JOptionPane.showConfirmDialog(null, "Would you like to add another student?");
		}while(addAnother == JOptionPane.YES_OPTION);
		
		printWriter.close();
		System.exit(0);

	}

}
