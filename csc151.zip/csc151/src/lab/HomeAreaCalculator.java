package lab;

import javax.swing.JOptionPane;

/*
 * Write a class that creates instances of the Rectangle class to find the 
 * total area of two rooms in a house.
 */
public class HomeAreaCalculator {

	public static void main(String[] args) {

		/**********************************
		 * 	RECTANGLE 1
		 **********************************/
		//Create instance of Rectangle class
		Rectangle room1 = new Rectangle();
		
		//Get input
		String input = JOptionPane.showInputDialog("Enter the length of your first room.");
		double length = Double.parseDouble(input);
		
		input = JOptionPane.showInputDialog("Enter the width of your first room.");
		double width = Double.parseDouble(input);
		

		room1.setLength(length);
		room1.setWidth(width);
		double areaOfRoom1 = room1.calculateArea();
		
		
		/**********************************
		 * 	RECTANGLE 2
		 **********************************/
		input = JOptionPane.showInputDialog("Enter the length of your second room");
		length = Double.parseDouble(input);
		
		input = JOptionPane.showInputDialog("Enter the width of your second room.");
		width = Double.parseDouble(input);
		
		//Create instance of Rectangle class
		Rectangle room2 = new Rectangle(length, width);
		double areaOfRoom2 = room2.calculateArea();
		
		
		
		//Get total area of both rooms
		double totalArea = areaOfRoom1 + areaOfRoom2;
		String message = String.format("The total area of both rooms is %.2f", totalArea);
		JOptionPane.showMessageDialog(null, message);
		System.exit(0);		
	}

}
