package lab;

public interface Game {
	
	int getNumberOfPlayers();
	void setNumberOfPlayers(int players);
	
	void print();
}
