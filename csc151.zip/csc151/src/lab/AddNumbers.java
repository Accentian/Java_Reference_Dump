package lab;

import javax.swing.JOptionPane;

/*
 * DO WHILE LOOP:
 * Write a program that allows a user to enter two numbers, 
 * and then sums up the two numbers. The user should be able to 
 * repeat this action until they indicate they are done.
 */
public class AddNumbers {

	public static void main(String[] args) {
		
		//Declare sentinel
		int again;
		
		do{
			String input = JOptionPane.showInputDialog("Enter the first number");
			double num1 = Double.parseDouble(input);
			
			input = JOptionPane.showInputDialog("Enter the second number");
			double num2 = Double.parseDouble(input);
			
			double sum = num1 + num2;
			
			String message = String.format("The sum is %.2f. Would you like to start over?", sum);
			again = JOptionPane.showConfirmDialog(null, message);
		}while(again == JOptionPane.YES_OPTION);
		
		System.exit(0);

	}

}
