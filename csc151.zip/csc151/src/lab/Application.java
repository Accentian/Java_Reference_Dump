package lab;

import java.util.Scanner;

public class Application {

	static Scanner keyboard = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		
		//Get names
		System.out.println("Player 1, please enter your name: ");
		String name = keyboard.nextLine();
		Player player1 = new Player(name);
		
		System.out.println("Player 2, please enter your name: ");
		name = keyboard.nextLine();
		Player player2 = new Player(name);
		
		//Start game and print instructions
		CoinGame game = new CoinGame(player1, player2);
		game.print();
		
		//Get guesses
		System.out.println(player1.getName() + ", guess Heads or Tails");
		String guess = keyboard.nextLine();
		guess = validateGuess(guess);
		player1.setGuess(guess);
		
		if(guess.equalsIgnoreCase("Heads")){
			player2.setGuess("Tails");
		}
		else{
			player2.setGuess("Heads");
		}
		
		//Flip coin
		Player winner = game.flip();
		System.out.println("The coin landed on " + game.getCoinValue() + " so " + winner.getName() + " is the winner!");
		
	}

	private static String validateGuess(String guess) {
		
		while(!guess.equalsIgnoreCase("heads") && !guess.equalsIgnoreCase("tails")){
			System.out.println("Invalid guess. Please enter Heads or Tails");
			guess = keyboard.nextLine();
		}
		
		return guess;
	}
		

}
