package lab;

public class Square extends Rectangle2{

	@Override
	public double calculatePerimeter(){
		return sides * length;
	}
	
	public void print(String who){
		System.out.println("I am a " + who);
	}
}
