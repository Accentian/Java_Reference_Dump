package lab;

import javax.swing.JOptionPane;

public class NumberCalc {
	
	public static double getNumberUser(){
		String numU1 = JOptionPane.showInputDialog("Enter a number.");
		double num1 = Double.parseDouble(numU1);
		
		String numU2 = JOptionPane.showInputDialog("Enter a second number.");
		double num2 = Double.parseDouble(numU2);
		
		double result = getFunctionType(num1, num2);
		return result;
		
	}
	
	public static double getFunctionType(double number1, double number2){
		String getFunType = JOptionPane.showInputDialog("Enter a function: A for Addition; S for Subtraction; M for Multiplication; and D for Division.");
		
		switch(getFunType){
		case "A":
			return add(number1, number2);
			
		case "S":
			return sub(number1, number2);
			
		case "M":
			return mult(number1, number2);
			
		case "D":
			return div(number1, number2);
			
		default:
			JOptionPane.showMessageDialog(null, "Invalid operation.");
			return 0;
		}
		
		
		}
	
	public static double add(double num1, double num2){
		double sum = num1 + num2;
		return sum;
	}
	
	public static double sub(double num1, double num2){
		double sum = num1 - num2;
		return sum;
	}
	
	public static double mult(double num1, double num2){
		double sum = num1 * num2;
		return sum;
	}
	
	public static double div(double num1, double num2){
		double sum = num1 / num2;
		return sum;
	}
		

	
	public static void main(String[] args) {
		
		double result = getNumberUser();
		String message = String.format("The result is %.2f", result);
		JOptionPane.showMessageDialog(null, message);

	}

}
