package lab;

import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		Employee employee = new Employee();
		employee.setAge(19);		
		System.out.println(employee.getAge());
		
		Scanner keyboard = new Scanner(System.in);
		Square square =  new Square();
		square.setLength(keyboard.nextDouble());
		square.setWidth(keyboard.nextDouble());
		System.out.println(square.calculatePerimeter());
		keyboard.close();
		
		Rectangle r = new Rectangle();
		r.calculatePerimeter();

	}

}
