package lab;

public interface Product2 {

	double getPrice();
	void setPrice(double price);
	
	String getName();
	void setName(String name);
	
	String getColor();
	void setColor(String color);

}
