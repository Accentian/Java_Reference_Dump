package lab;

public class CoinGame implements Game {
	private int numberOfPlayers;
	private Player player1;
	private Player player2;
	private Coin coin;
	
	public CoinGame(Player p1, Player p2){
		player1 = p1;
		player2 = p2;
		coin = new Coin();
		numberOfPlayers = 2;
	}

	public Player[] getPlayers() {
		Player players[] = {player1, player2};
		return players;
	}
	
	public int getNumberOfPlayers(){
		return numberOfPlayers;
	}
	
	@Override
	public void setNumberOfPlayers(int players) {
		this.numberOfPlayers = players;
	}
	
	public Player flip(){
		String value = coin.flip();
		
		if(player1.getGuess().equalsIgnoreCase(value)){
			return player1;
		}
		else{
			return player2;
		}
	}
	
	public String getCoinValue(){
		return coin.getCoinValue();
	}
	
	public void print() {
		System.out.println("The players will pick either heads or tails, the winner will be determine by the result from a flipped coin.");
	}
	
}
