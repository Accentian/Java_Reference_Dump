package lab;

import javax.swing.JOptionPane;

public class WeddingCake extends Cake{
	
	protected int tiers;
	
	public WeddingCake(int tiers, String flavor){
		super(flavor);
		setTiers(tiers);
	}
	
	public int getTiers(){
		return tiers;
	}
	
	public void setTiers(int tiers){
		this.tiers = tiers;
	}
	
	public void showMessage(){
		String message = String.format("Thank you for the purchased of %s wedding cake, with %d tiers.", flavor, tiers);
		JOptionPane.showConfirmDialog(null, message);
	}

}
