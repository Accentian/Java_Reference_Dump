package lab;

public class Employee extends Person{
 
	public Employee(){
		this("");
	}
	
	public Employee(String name){
		super(name);
	}

}
