package lab;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyCanvas extends JFrame{
	
	private static final long serialVersionUID = 1L;
	protected JPanel panel;
	
	public MyCanvas(){
		setTitle("My Canvas");
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildPanel();
	}
	
	protected void buildPanel(){
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		
		JButton button = new JButton("Click me");
		button.addActionListener(new ColorChangeListener());
		panel.add(button);
		
		add(panel);
	}

	public static void main(String[] args) {
		MyCanvas canvas = new MyCanvas();
		canvas.setVisible(true);
	}
	
	private class ColorChangeListener implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			Random random = new Random();
			int randomInt = random.nextInt(5);
			
			switch(randomInt){
			case 0:
				panel.setBackground(Color.BLACK);
				break;
			case 1:
				panel.setBackground(Color.CYAN);
				break;
			case 2:
				panel.setBackground(Color.GREEN);
				break;
			case 3: 
				panel.setBackground(Color.RED);
				break;
			case 4:
				panel.setBackground(Color.YELLOW);
				break;
			default:
				panel.setBackground(Color.WHITE);
				break;
			}
		}
		
	}
	
	
	
}
