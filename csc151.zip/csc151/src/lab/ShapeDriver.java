package lab;

public class ShapeDriver {

	public static void main(String[] args) {
		Shape rectangle = new Rectangle3(5, 7);
		rectangle.print();
		

	}

}
