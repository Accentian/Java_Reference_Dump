package lab;

import javax.swing.JOptionPane;

public class SpeedLimit {

	public static void main(String[] args) {
		
		String spdInput = JOptionPane.showInputDialog("Enter your speed.");
		int spdNum = Integer.parseInt(spdInput);
		
		Integer spdMax = 65;
		Integer spdMin = 45;
		
		if(spdNum > spdMax){
			JOptionPane.showMessageDialog(null, "You are exceeding the maximum speed limit. Please decrease your speed to no more than " + spdMax +" MPH");
		}
		else if(spdNum < spdMin){
			JOptionPane.showMessageDialog(null, "You are driving below the speed limit. Please increase your speed to at least " + spdMin + " MPH.");
		}
		else if(spdNum <= spdMax && spdNum >= spdMin){
			JOptionPane.showMessageDialog(null, "You are within acceptable speed limit.");
		}
		
		System.exit(0);

	}

}
