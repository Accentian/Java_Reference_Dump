package lab;

public class MonthConverter {

	public static void main(String[] args) {
		String month1 = Month.getMonth(2);
		System.out.println(month1);
		
		int month2 = Month.getMonth("January");
		System.out.println(month2);

	}

}
