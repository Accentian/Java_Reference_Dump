package lab;

public class ParkingLot {
	
	public static void main(String args[]){
		
		Car car = new Coupe();
		car.setMiles(120);
		car.setMake("Honda");
		car.setModel("Civic");
		car.move();
		car.identify();
		
	}
	
	
}
