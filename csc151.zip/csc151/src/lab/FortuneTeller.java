package lab;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class FortuneTeller extends MyCanvas{
	
	private static final long serialVersionUID = 1L;
	JLabel label;
	
	public FortuneTeller(){
		setTitle("Fortune Teller");
		setSize(590, 500);
	}
	
	protected void buildPanel(){
		panel = new JPanel();
		panel.setBackground(Color.MAGENTA);
		
		label = new JLabel();
		panel.add(label);
		
		JLabel image = new JLabel(new ImageIcon("resources/teller1.gif"));
		panel.add(image);
		
		JButton button = new JButton("Tell Me My Fortune");
		button.addActionListener(new PhraseGeneratorListener());
		panel.add(button);
		
		add(panel);
	}
	
	private class PhraseGeneratorListener implements ActionListener{
		List<String> phrases;
		
		public PhraseGeneratorListener(){
			generatePhrases();
		}
		
		public void actionPerformed(ActionEvent e) {
			label.setText(chooseRandomPhrases());;
		}
		
		private void generatePhrases(){
			phrases = new ArrayList<String>();
			phrases.add("You might get a good grade.");
			phrases.add("Do not try to change the outcome.");
			phrases.add("Nothing will be done if one delays.");
			phrases.add("Keep trying, perhaps.");
			phrases.add("Ask me later, mortal.");
			phrases.add("So it goes.");
		}
		
		private String chooseRandomPhrases(){
			Random random = new Random();
			return phrases.get(random.nextInt(phrases.size()));
		}
		
	}
	
	public static void main(String[] args) {
		FortuneTeller window = new FortuneTeller();
		window.setVisible(true);

	}

}
