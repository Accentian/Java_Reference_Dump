package lab;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayNameInput {
	
	private static String name[];

	public static void main(String[] args) {
		System.out.println("How many students would you like to enter?");
		
		Scanner keyboard = new Scanner(System.in);
		int arraySize = keyboard.nextInt();
		name = new String[arraySize];
		
		for(int i=0; i<arraySize; i++){
			System.out.println("Enter the student's name " + (i+1));
			name[i] = keyboard.next();
		}
		
		Arrays.sort(name);
		printName(arraySize, name);
		
	}
	
	public static void printName(int arraySize, String name[]){
		System.out.print("Student's name entered: ");
		
		for(int i=0; i<arraySize; i++){
			System.out.print(name[i] + " | ");
		}
	}

}
