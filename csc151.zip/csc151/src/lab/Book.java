package lab;

public class Book implements Product2{

	private double price;
	private String name;
	private String color;
	
	private String author;
	private String genre;
	private int pages;
	private String isbn;
	
	@Override
	public double getPrice() {
		return price;
	}

	@Override
	public void setPrice(double price) {
		this.price = price;		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setColor(String color) {
		// TODO Auto-generated method stub
		
	}
	

}
