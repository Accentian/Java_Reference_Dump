package lab;

import javax.swing.JOptionPane;

/*
 * IF PROBLEM:
 * All salespersons get a payment of $1000 for the week. 
 * Salespersons who exceed 10 sales get an additional bonus of $250. 
 */
public class SalaryCalculator {

	public static void main(String[] args) {
		//Initialize known variables
		int salary = 1000;
		int bonus = 250;
		
		//Get values for the unknown
		String input = JOptionPane.showInputDialog("How many sales did the employee make this week?");
		int sales = Integer.parseInt(input);
		
		//Quick detour for the bonus earners
		if(sales > 10){
			salary = salary + bonus;
		}
		
		//Output pay
		String output = "Pay: $" + salary;
		JOptionPane.showMessageDialog(null, output);
		
		System.exit(0);

	}

}
