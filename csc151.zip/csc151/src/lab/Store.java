package lab;

public class Store {

	public static void main(String[] args) {
		
		Garment garment = new Hat("Fedora", "It's fancy and classic.", "Black", 5.99);
		garment.order();
	}

}
