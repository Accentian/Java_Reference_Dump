package lab;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class NumberReaderOutput {

	public static void main(String[] args) throws IOException {
		File file = new File("resources/numbers.txt");
		Scanner fileReader = new Scanner(file);
		
		int counter = 0;
		int smallest = 0;
		int largest = 0;
		int total = 0;
		
		while(fileReader.hasNextLine()){
			int number = fileReader.nextInt();
			
			if(counter == 0){
				smallest = number;
				largest = number;
			}
			
			if(number < smallest){
				smallest = number;
			}
			
			if(number > largest){
				largest = number;
			}
			
			total = total + number;
			
			counter++;
		}
		
		int average = total / counter;
		
		fileReader.close();
		
		file = new File("resources/results.txt");
		file.createNewFile();
		
		FileWriter writer = new FileWriter(file, true);
		PrintWriter print = new PrintWriter(writer);
		
		String message = String.format("The sum is %d", total);
		print.println(message);
		
		message = String.format("The average is %d", average);
		print.println(message);
		
		message = String.format("The smallest is %d", smallest);
		print.println(message);
		
		message = String.format("The largest is %d", largest);
		print.println(message);
		
		writer.close();
		print.close();

	}

}
