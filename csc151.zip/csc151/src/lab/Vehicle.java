package lab;

public abstract interface Vehicle {
	
	double getMiles();
	void setMiles(double miles);
	
	String getColor();
	void setColor(String color);
	
	void move();
	void identify();

}
