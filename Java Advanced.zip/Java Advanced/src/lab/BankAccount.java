package lab;
import java.text.NumberFormat;


public class BankAccount {

	public static void main(String[] args) {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		//create accounts
		SavingsAccount save = new SavingsAccount("A12345", 650.00);
		SavingsAccount save2 = new SavingsAccount("X12345", 60000.00); //initial deposit with bonus
		SavingsAccount save3 = new SavingsAccount("Y12345", 5.00);//initial deposit too small
		CheckingAccount check = new CheckingAccount("B12345", 700.00);
		
		//check account ids
		System.out.println("Checking account id is: " + check.getId());
		System.out.println("Savings account 1 id is: " + save.getId());
		System.out.println("Savings account 2 id is: " + save2.getId());
		System.out.println("Savings account 3 id is: " + save3.getId());
		
		//check account balances
		System.out.println("Checking account balance is: " + nf.format(check.getBalance()));
		System.out.println("Savings account 1 balance is: " + nf.format(save.getBalance()));
		System.out.println("Savings account 2 balance is: " + nf.format(save2.getBalance()));
		System.out.println("Savings account 3 balance is: " + nf.format(save3.getBalance()));
		
		//check withdraw function on savings account
		save.withdraw(700.00); //too much
		save.withdraw(649.00); //too much with fee
		save.withdraw(200); //success
		
		//check withdraw on checking account
		check.withdraw(800);//too much
		check.withdraw(50);//success
		//check Check functionality
		System.out.println("You have used " + check.getChecksUsed() + " checks.");//see checks used
		check.withdrawUsingCheck(1000);//too much
		check.withdrawUsingCheck(50);//check withdrawal success
		check.withdrawUsingCheck(50);//check withdrawal success
		check.withdrawUsingCheck(50);//check withdrawal success
		check.withdrawUsingCheck(50);//check withdrawal success + incur fee
		System.out.println("You have used " + check.getChecksUsed() + " checks.");//see checks used
		check.resetChecksUsed();//reset checks used
		System.out.println("You have used " + check.getChecksUsed() + " checks.");//check reset functionality
		
		check.withdrawUsingCheck(10000.00);//check withdrawal too much
		
		System.out.println("Interest for this account has been calculated a .45% giving you "
				+ "an extra " + nf.format(save2.addInterest(.45)) + " bringing you balance to " + nf.format(save2.getBalance()) + ".");
		
		System.out.println("Checking account balance is: " + nf.format(check.getBalance()));//see balance
		System.out.println("Savings account 1 balance is: " + nf.format(save.getBalance()));//see balance
		System.out.println("Savings account 2 balance is: " + nf.format(save2.getBalance()));//see balance
		System.out.println(save.toString());
		System.out.println(save2.toString());
		System.out.println(save3.toString());
		System.out.println(check.toString());
		
		
	}//end main

}//end class BankAccount

//abstract super class
abstract class Account{
	//attributes
	protected String _id;
	protected double _balance;
	
	public Account(String id, double initialBalance) {
		_balance = initialBalance;
		_id = id;
		
	}

	public String getId() {
		return _id;
	}

	public double getBalance() {
		return _balance;
	}

	@Override
	public String toString() {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		return "ID:" + _id + ", Balance:" + nf.format(_balance);
	}
	
	public abstract boolean withdraw(double amount);
	public abstract void deposit(double amount);
	
}//end abstract class Account

class SavingsAccount extends Account{

	private double ATMFEE = 2;

	public SavingsAccount(String id, double initialBalance) {
		super(id, initialBalance);
		_balance = initialBalance;


		NumberFormat nf = NumberFormat.getCurrencyInstance();
		if (_balance < 10) {
			System.out.println("Minimum initial deposit must be greater that $10. Balance remains $0.");
			_balance = 0;
		}
		else if (_balance > 10000) {
			System.out.println("Congratulations! an extra $200 has been added to your Savings account for making an "
					+ "initial deposit of more than $10,000!");
			_balance = _balance + 200;
			System.out.println("Your initial deposit is now " + nf.format(_balance));
		}
		else {
			System.out.println("Thank you for your initial deposit of " + nf.format(_balance) + " into your Savings Account.");
		}

	}

	@Override
	public boolean withdraw(double amount) {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		if ((_balance - (amount + ATMFEE) < 10)) {
			System.out.println("You cannot make a withdrawl that will bring your balance below $10.");
			System.out.println("Your Current balance is " + nf.format(_balance) + ".");
			System.out.println("And the withdrawl fee is " + nf.format(ATMFEE) + ".");
			return false;			
		}
		else {
			_balance = _balance - (amount + ATMFEE);
			System.out.println("Withdrawl of " + nf.format(amount) + " successful.");
			System.out.println("Withdrawl fee of " + nf.format(ATMFEE) + " charged to Savings account.");
			System.out.println("Remaning balance: " + nf.format(_balance));
			return true;
		}

	}

	@Override
	public void deposit(double amount) {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		System.out.println("Deposit of " + nf.format(amount) + " made to Savings Account.");
		_balance = _balance + amount;
	}
	
	public double addInterest(double rate) {
		double interest = _balance * (rate/100);
		_balance = _balance + interest;
		return interest;
 	}
	
}//end Savings Account

class CheckingAccount extends Account{
	
	private int numberOfChecksUsed = 0;
	private double ATMFEE = 1;
	private double CHECKFEE = 2;
	

	public CheckingAccount(String id, double initialBalance) {
		super(id, initialBalance);
		_balance = initialBalance;
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		System.out.println("Thank you for your initial deposit of " + nf.format(_balance) + " into your Checking Account.");
	}

	@Override
	public boolean withdraw(double amount) {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		if ((_balance - (amount + ATMFEE) < 0)) {
			System.out.println("You cannot make a withdrawl that will bring your balance below $0.");
			System.out.println("Your Current balance is " + nf.format(_balance) + ".");
			System.out.println("And the withdrawl fee is " + nf.format(ATMFEE) + ".");
			return false;
		}
		else {
			_balance = _balance - (amount + ATMFEE);
			System.out.println("Withdrawl of " + nf.format(amount) + " successful.");
			System.out.println("Withdrawl fee of " + nf.format(ATMFEE) + " charged to Checking account.");
			System.out.println("Remaning balance: " + nf.format(_balance));
			return true;
		}
	}

	@Override
	public void deposit(double amount) {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		System.out.println("Deposit of " + nf.format(amount) + " made to Checking Account.");
		System.out.println("ATM Deposit fee of " + nf.format(ATMFEE) + " charged to Checking account.");
		_balance = _balance + (amount - ATMFEE);
	}
	
	public void resetChecksUsed() {
		numberOfChecksUsed = 0;
	}
	
	public int getChecksUsed() {
		return numberOfChecksUsed;
	}
	
	public boolean withdrawUsingCheck(double amount) {
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		if (numberOfChecksUsed > 2) {
			if ((_balance - (amount + CHECKFEE) < -10)) {
				System.out.println("You cannot make a withdrawl that will bring your balance below $-10.");
				System.out.println("Your Current balance is " + nf.format(_balance) + ".");
				System.out.println("And the withdrawl fee for checks is " + nf.format(CHECKFEE) + " after the 3rd check.");
				System.out.println("You have used " + numberOfChecksUsed + " check(s) this month.");
				return false;
			}
			else {
				_balance = _balance - (amount + CHECKFEE);
				numberOfChecksUsed += 1;
				System.out.println("Withdrawl of " + nf.format(amount) + " successful.");
				System.out.println("Withdrawl fee of " + nf.format(CHECKFEE) + " charged to Checking account.");
				System.out.println("You have used " + numberOfChecksUsed + " check(s) this month.");
				System.out.println("Remaning balance: " + nf.format(_balance));
				return true;
			}
		}
		else {
			if ((_balance - amount < -10)) {
				System.out.println("You cannot make a withdrawl that will bring your balance below $-10.");
				System.out.println("Your Current balance is " + nf.format(_balance) + ".");
				System.out.println("And the withdrawl fee for checks is " + nf.format(CHECKFEE) + " after the 3rd check.");
				System.out.println("You have used " + numberOfChecksUsed + " check(s) this month.");
				return false;
			}
			else {
				_balance = _balance - amount;
				numberOfChecksUsed += 1;
				System.out.println("Withdrawl of " + nf.format(amount) + " successful.");
				System.out.println("No withdrawl fee charged to Checking account until 3 checks have been used this month.");
				System.out.println("You have used " + numberOfChecksUsed + " check(s) this month.");
				System.out.println("Remaning balance: " + nf.format(_balance));
				return true;
			}
		}
	}
}