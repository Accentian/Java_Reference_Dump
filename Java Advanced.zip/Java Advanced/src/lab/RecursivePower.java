package lab;

import javax.swing.JOptionPane;

/*
 * Accepts user input of two integers, raising the first to the power of the second using recursive method
 * Author: Jeremy Trantham, Date: 1/30/18
 */

public class RecursivePower {

	public static void main(String[] args) {
		
		//
		int base = Integer.parseInt(JOptionPane.showInputDialog("Enter the base number: "));
		int exponent = Integer.parseInt(JOptionPane.showInputDialog("Enter the exponent: "));
		
		long result = power(base, base, exponent);
		JOptionPane.showMessageDialog(null, result);
		System.exit(0);
	}
	
	/*
	 * Recursive method that will raise base to the power of exponent
	 */
	
	public static long power(long currentProduct, int base, int exponent) {
		if (exponent > 1) {
			return power(currentProduct * base, base, exponent - 1);
		}
		else {
			return currentProduct;
		}
	}

}