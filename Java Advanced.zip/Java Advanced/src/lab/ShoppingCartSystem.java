package lab;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ShoppingCartSystem extends JFrame {

	// Variables
	private String selection;
	private JPanel bookPanel;
	private JList bookList;
	private JList selectedBookList;
	private JList displayCheckOutList;

	// Checkout labels and text fields
	private JTextField subTotalDisplay;
	private JLabel subTotal;
	private JLabel total;
	private JTextField totalDisplay;
	private JLabel tax;
	private JTextField taxDisplay;

	private DefaultListModel model;

	String[] books = new String[9];
	String[] selectedBooks = {"", "", "", "", "", "", "", "", ""};
	int howMany = 0;

	double taxValue = 0.06;
	double subTotalValue = 0;
	double totalValue = 0;
	double value = 0;
	String subTotalString;
	String taxString;
	String totalString;

	// List panes
	private JScrollPane scrollPane1;

	// Button 
	private JPanel buttonPanel;
	private JButton addButton;
	private JPanel removePanel;
	private JButton removeButton;
	private JPanel clearPanel;
	private JButton clearButton;
	private JPanel checkOutPanel;
	private JButton checkOutButton;

	// Menu bar
	private JMenuBar menuBar;
	private JMenu fileMenu;
	private JMenuItem exitOption;

	// Constructor
	public ShoppingCartSystem(){
		// Reading from text file
		File file = new File("textfile/BookPrices.txt");
		Scanner fileReader;
		try {
			fileReader = new Scanner(file);

			int i = 0;
			while (fileReader.hasNext()){
				// Adds to array
				books[i] = fileReader.nextLine();
				i++;
			} // End while loop

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} // End catch

		setTitle("Shopping Cart");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());

		// Build selected panel and button panel
		buildBookPanel();
		buildButtonPanel();
		buildRemovePanel();
		buildClearPanel();
		buildCheckOutPanel();

		// Add panels to frame
		add(bookPanel, BorderLayout.NORTH);
		add(addButton, BorderLayout.WEST);
		add(removeButton, BorderLayout.EAST);
		add(clearButton, BorderLayout.CENTER);
		add(checkOutButton, BorderLayout.SOUTH);

		pack();
		setVisible(true);
	} // End Constructor

	// Book panel
	private void buildBookPanel() {
		// Build book panel
		//buildBookPanel();
		bookPanel = new JPanel();
		bookList = new JList(books);
		bookList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// Action listener event
		bookList.addListSelectionListener(new ListListener());

		// Set visibility same amount in text file
		bookList.setVisibleRowCount(9);

		// Add list to scroll pane
		scrollPane1 = new JScrollPane(bookList);

		// Add list to panel
		bookPanel.add(scrollPane1);

		model = new DefaultListModel();
		selectedBookList = new JList(model);
		selectedBookList.setPreferredSize(new Dimension(200, 163));;
		selectedBookList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// Set visibility same amount in text file
		selectedBookList.setVisibleRowCount(9);

		bookPanel.add(selectedBookList);

		// Checkout labels and text field
		subTotal = new JLabel("Subtotal: ");
		subTotalDisplay = new JTextField(10);
		subTotalDisplay.setEditable(false);

		tax = new JLabel("Tax: ");
		taxDisplay = new JTextField(10);
		taxDisplay.setEditable(false);

		total = new JLabel("Total: ");
		totalDisplay = new JTextField(10);
		totalDisplay.setEditable(false);

		// JMenu Bar
		menuBar = new JMenuBar();
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		exitOption = new JMenuItem("Exit");
		exitOption.setMnemonic(KeyEvent.VK_X);
		exitOption.addActionListener(new ExitListener());
		// Add to panel
		fileMenu.add(exitOption);

		bookPanel.add(subTotal);
		bookPanel.add(subTotalDisplay);
		bookPanel.add(tax);
		bookPanel.add(taxDisplay);
		bookPanel.add(total);
		bookPanel.add(totalDisplay);
		menuBar.add(fileMenu);
		setJMenuBar(menuBar);

	} // End buildBookPanel

	// Build button panel
	private void buildButtonPanel(){
		// Create panel to hold the list
		buttonPanel = new JPanel();

		// Create button
		addButton = new JButton("Add");

		// Add action listener
		addButton.addActionListener(new ButtonListener());
		// Add button to panel
		buttonPanel.add(addButton);
	} // End buildButtonPanel

	// Build remove panel
	private void buildRemovePanel(){
		removePanel = new JPanel();

		removeButton = new JButton("Remove");
		removeButton.addActionListener(new RemoveListener());
		removePanel.add(removeButton);
	} // End remove panel

	private void buildClearPanel(){
		clearPanel = new JPanel();
		clearButton = new JButton("Clear All");
		clearButton.addActionListener(new ClearListener());
		clearPanel.add(clearButton);
	}

	private void buildCheckOutPanel(){
		checkOutPanel = new JPanel();
		checkOutButton = new JButton("Checkout");
		checkOutButton.addActionListener(new CheckOutListener());
		checkOutPanel.add(checkOutButton);
	}

	private class ListListener implements ListSelectionListener{

		@Override
		public void valueChanged(ListSelectionEvent e) {
			selection = (String) bookList.getSelectedValue();
			selectedBooks[howMany] = selection;
			howMany++;
		}

	} // End list listener 



	private class ButtonListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e){
			model.addElement(selection);

		}

	} // End button listener

	private class RemoveListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			model.removeElement(selection);

		}
	} // End remove listener

	private class ClearListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			model.removeAllElements();

		}
	} // End clear listener

	/////////////////////////////////////////////// !!!!!CHECKOUT AREA HERE! HAVING ISSUES!!!!!
	private class CheckOutListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			for(int i = 0; i <= model.size(); i++){
				
				String checkOutReader = (String) model.getElementAt(i);
				
				value = Double.parseDouble(checkOutReader);
				
				subTotalValue = subTotalValue + value;
			}

			totalValue = subTotalValue * taxValue;

			subTotalString = String.valueOf(subTotalValue);
			taxString = String.valueOf(taxValue);
			totalString = String.valueOf(totalValue);

			subTotalDisplay.setText(subTotalString);
			taxDisplay.setText(taxString);
			totalDisplay.setText(totalString);
		}
	} // End checkout listener

	private class ExitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.exit(0);

		}

	} // End ExitListener

	public static void main(String[] args) {
		new ShoppingCartSystem();



	} // End main

} // End class
