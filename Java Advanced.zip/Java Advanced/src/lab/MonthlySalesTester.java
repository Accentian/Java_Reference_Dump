package lab;

import javax.swing.JFrame;

public class MonthlySalesTester {

	public static void main(String[] args) {
		MonthlySalesTax gui = new MonthlySalesTax();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setSize(500,500);
		gui.setVisible(true);

	}

}
