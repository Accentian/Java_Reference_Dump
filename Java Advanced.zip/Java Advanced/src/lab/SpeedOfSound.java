package lab;

public class SpeedOfSound {

	public static void main(String[] args) {
		Speed R1 = new Speed("Air");
		Speed R2 = new Speed("Water");
		
		R1.start();
		R2.start();
		
	} // End main

} // End class



class Speed implements Runnable {
	private Thread t;
	private String threadName;
	
	Speed(String name) {
		threadName = name;
		System.out.println("Creating thread " + threadName);
	}
	
	public void start(){
		System.out.println("Starting " + threadName);
		if(t == null){
			t = new Thread(this, threadName);
			t.start();
		}
	} // End start
	
	// No sleep thread = no try and catch
	@Override
	public void run() {
		System.out.println("Running thread " + threadName);
		double time = 0.00;
		
		for(double distance = 1000.00; distance <= 1100.00; distance++){
			if (threadName.equals("Air")) {
				time = distance / 1100;
				System.out.printf(threadName + " at %.0f meters is %.5f \n", distance, time);
			} // End if
			else { // Water
				time = distance / 4900;
				System.out.printf(threadName + " at %.0f meters is %.5f \n", distance, time);
			} // End else
		} // End for
		
		// Thread finishes
		System.out.println("Thread " + threadName + " exiting");
		
	} // End run
	
	
} // End class


