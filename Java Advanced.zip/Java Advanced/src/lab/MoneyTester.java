/*
 * Tester app for MoneyConverter
 */

package lab;

import javax.swing.JFrame;

public class MoneyTester {

	public static void main(String[] args) {
		MoneyConverter gui = new MoneyConverter();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setSize(400,400);
		gui.setVisible(true);
	} // End main

} // End class
