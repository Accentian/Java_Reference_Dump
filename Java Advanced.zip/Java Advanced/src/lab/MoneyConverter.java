package lab;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class MoneyConverter extends JFrame {
	private JTextField txtDollars;
	private JLabel lblEnterDollars;
	private JRadioButton rdbtnEuro;
	private JRadioButton rdbtnYen;
	private JButton btnConvert;
	private ButtonGroup group;
	
	// Conversion rate
	private double EURO_FACTOR = 1.09;
	private double YEN_FACTOR = 0.0083;
	
	public MoneyConverter() {
		setupFrame();
	} //End constructor
	
	private void setupFrame() {
			
		getContentPane().setLayout(null);
		
		lblEnterDollars = new JLabel("Enter Dollars");
		lblEnterDollars.setBounds(67, 44, 86, 14);
		getContentPane().add(lblEnterDollars);
		
		txtDollars = new JTextField();
		txtDollars.setBounds(186, 41, 86, 20);
		getContentPane().add(txtDollars);
		txtDollars.setColumns(10);
		
		rdbtnEuro = new JRadioButton("Euro");
		rdbtnEuro.setSelected(true);
		rdbtnEuro.setBounds(100, 97, 109, 23);
		getContentPane().add(rdbtnEuro);
		
		rdbtnYen = new JRadioButton("Yen");
		rdbtnYen.setBounds(100, 123, 109, 23);
		getContentPane().add(rdbtnYen);
		
		group = new ButtonGroup();
		group.add(rdbtnEuro);
		group.add(rdbtnYen);
		
		btnConvert = new JButton("Convert");
		btnConvert.setBounds(183, 153, 89, 23);
		getContentPane().add(btnConvert);
		
		//Create our button event
		btnConvert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String dollars = txtDollars.getText();
				double answer = 0.00;
				if (rdbtnEuro.isSelected()) {
					answer = Double.parseDouble(dollars) * EURO_FACTOR;
				} // End if
				else { // User selected Yen
					answer = Double.parseDouble(dollars) * YEN_FACTOR;
				} // End else
				
				// Display answer in currency format
				NumberFormat formatter = new DecimalFormat("#0.00");
				JOptionPane.showMessageDialog(null, "Answer is " + formatter.format(answer));
				
				
			} // End ActionPerformed
			
		});
		
		
	} // End setupFrame
} // End class
