package lab;

import java.util.Scanner;

public class FactorialExample {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a number and I will calculate the factorial: ");
		long number = input.nextLong();
		
		System.out.println(number + "! is " + calcFactorial(number));
		
	} // End main
	
	// Recursion method to do factorial
	public static long calcFactorial(long n) {
		if(n == 0){
			return 1;
		}
		else {
			return n * calcFactorial(n - 1);
		}
	} // End calcFactorial

} // End class
