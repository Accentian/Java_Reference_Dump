package lab;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JButton;

public class GUIExample extends JFrame {
	private JTextField txtFirstInt;
	private JTextField txtSecondInt;
	private JLabel lblEnterFirstInteger;
	private JLabel lblEnterSecondInteger;
	private JButton btnAdd;
	private JLabel lblAnswer;
	
	public GUIExample() {
		setupFrame();
	}	//End of constructor
	
	private void setupFrame() {
		
		getContentPane().setLayout(null);
		
		lblEnterFirstInteger = new JLabel("Enter first integer");
		lblEnterFirstInteger.setBounds(79, 62, 122, 22);
		getContentPane().add(lblEnterFirstInteger);
		
		txtFirstInt = new JTextField();
		txtFirstInt.setBounds(211, 63, 86, 20);
		getContentPane().add(txtFirstInt);
		txtFirstInt.setColumns(10);
		
		lblEnterSecondInteger = new JLabel("Enter second integer");
		lblEnterSecondInteger.setBounds(79, 114, 122, 14);
		getContentPane().add(lblEnterSecondInteger);
		
		txtSecondInt = new JTextField();
		txtSecondInt.setBounds(211, 111, 86, 20);
		getContentPane().add(txtSecondInt);
		txtSecondInt.setColumns(10);
		
		btnAdd = new JButton("Add");
		btnAdd.setBounds(147, 158, 89, 23);
		getContentPane().add(btnAdd);
		
		lblAnswer = new JLabel("Answer");
		lblAnswer.setBounds(147, 203, 89, 14);
		getContentPane().add(lblAnswer);
		
		// Code the button event
		btnAdd.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// Perform these statements
				String firstNum = txtFirstInt.getText();
				String secondNum = txtSecondInt.getText();
				int answer = Integer.parseInt(firstNum) + Integer.parseInt(secondNum);
				lblAnswer.setText("Answer is " + answer);
				
				//Alternative coding in one line:
				//lblAnswer.setText("Answer is " + (Integer.parseInt(txtFirstInt.getText()) + (Integer.parseInt(txtSecondInt.getText())));
			}
			
			
		});
		
		
	} // End setupFrame
} // End class
