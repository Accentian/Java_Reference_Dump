package lab;

import java.util.Scanner;

public class AddingNumbers {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a number and I will add the numbers down to the number range: ");
		long number = input.nextLong();
		
		System.out.print("Enter the number range: ");
		long numRange = input.nextLong();
		
		System.out.println("Adding the number from " + number + " with the number range " + numRange + " is " + calcNumber(number, numRange));
		
	} // End main
	
	public static long calcNumber(long n1, long n2){
		if(n1 == n2){
			return n2;
		}
		else {
			return n1 + calcNumber(n1 - 1, n2);
		}
	} // End calcNumber

} // End class
