package lab;

import java.text.MessageFormat;
import java.util.Scanner;

public class BankingAccount {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		SavingsAccount savingsAccount = new SavingsAccount("Ghosh", 10000);
		savingsAccount.toString();
		
		System.out.print("Enter the amount you wish to withdraw: ");
		double amount = input.nextDouble();
		savingsAccount.withdraw(amount);
		
		System.out.print("Enter the amount you wish to deposit: ");
		amount = input.nextDouble();
		savingsAccount.deposit(amount);
		
		savingsAccount.addInterest(amount);
		
		CheckingAccount checkingAccount = new CheckingAccount("Ghosh", 10000);
		
		System.out.print("Enter the amount you wish to withdraw from your checking account: ");
		amount = input.nextDouble();
		checkingAccount.withdraw(amount);
		
		System.out.print("Enter the amount you wish to deposit: ");
		amount = input.nextDouble();
		checkingAccount.deposit(amount);
		
		System.out.print("Enter the amount you wish to withdraw by check: ");
		amount = input.nextDouble();
		checkingAccount.withdrawUsingCheck(amount);

	} // End main

} // End class

// Abstract Account
abstract class Account2 {
	protected String _id; // Form of account identification
	protected double _balance; // Stores the current balance

	// Constructor
	public Account2(String id, double balance){
		_id = id;
		_balance = balance;
	} // End constructor

	public String getID() {
		return _id;
	}

	public double getBalance() {
		return _balance;
	}

	public String toString() {
		String message = MessageFormat.format("ID: {0}, Balance: {1}", _id, _balance);
		System.out.println(message);
		return message;
		
	}

	abstract public boolean withdraw(double amount);
	abstract public void deposit(double amount);

} // End Account

class SavingsAccount2 extends Account{

	// Constructor
	public SavingsAccount2(String id, double initalBalance){
		super(id, initalBalance);
		if(initalBalance >= 10000){
			initalBalance = initalBalance + 200.00;
		}else{
			initalBalance = initalBalance + 0;
		}
	}

	@Override
	public boolean withdraw(double amount) {
		double balance = _balance - amount;

		if(balance < 10){
			System.out.println("Balance must not be less than $10.");
			return false;
		}else{
			_balance = _balance - amount;
			return true;

		}
	}

	@Override
	public void deposit(double amount) {
		if(amount >= 1){
			_balance = _balance + amount;
		}else{
			System.out.println("Invalid deposit.");
		}

	}
	
	// When to use this?
	public double addInterest(double rate){
		double rate_in_percentage = 0.25;
		double interestRate = _balance * (rate_in_percentage / 100);
		return _balance = _balance + interestRate;

	}

} // End SavingsAccount

class CheckingAccount2 extends Account{
	private int numberOfChecksUsed = 0; // Store number of check used per month. Can reset,

	// Constructor
	public CheckingAccount2(String id, double initalBalance){
		super(id, initalBalance);
	}

	@Override
	public boolean withdraw(double amount) {
		double balance = _balance - amount;
		double fee = 1;

		if(balance < 0){
			System.out.println("Balance must not be less than $0.");
			return false;
		}else{
			_balance = _balance - (amount + fee);
			return true;

		}
	}

	@Override
	public void deposit(double amount) {
		double fee = 1;
		if(amount >= 1){
			_balance = _balance + (amount - fee);
		}else{
			System.out.println("Invalid deposit.");
		}	
	}
	
	// Use a counter to reset after a certain threshold?
	public void resetCheckUsed(){
		numberOfChecksUsed = 0;
	}
	
	public int getCheckUsed(){
		numberOfChecksUsed++;
		return numberOfChecksUsed;
	}
	
	public boolean withdrawUsingCheck(double amount){
		double balance = _balance - amount;
		double checkFee = 0;
		
		if(numberOfChecksUsed <= 3){
			if(balance < -10){
				System.out.println("Checking withdrawal amount must not lower the balance below -$10.");
				return false;
			}else{
				_balance = _balance - amount;
				return true;
			}
		}else{
			if(balance < -10){
				System.out.println("Checking withdrawal amount must not lower the balance below -$10.");
				return false;
			}else{
				_balance = _balance - (amount + checkFee);
				return true;
			}
		}
	}
		
} // End CheckingAccount

