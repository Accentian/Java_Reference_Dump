package lab; 

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JApplet;

public class HouseApp extends JApplet {
	boolean lightsOn = false;
	
	public void init() {
		getContentPane().setBackground(Color.white);
		addMouseListener(new MyMouseListener());
	}
	
	private class MyMouseListener extends MouseAdapter
	   {
		 public void mouseClicked(MouseEvent e)
	      {
			 lightsOn = !lightsOn;
			 repaint();
	      }
		
	   }

	// Creating the house
	public void paint(Graphics g) {
		int[] xCoords = {20, 100, 180};
		int[] yCoords = {60, 20, 60};
		
		super.paint(g);
		g.setColor(Color.red);
		g.fillPolygon(xCoords, yCoords, 3);
		
		g.setColor(Color.blue);
		g.fillRect(40, 60, 120, 100);
		
		// I add logic for one window, you need to do the rest.
		if (!lightsOn) g.setColor(Color.black);
		else g.setColor(Color.white);
		g.fillRect(55, 80, 30, 30);
		
		if (!lightsOn) g.setColor(Color.black);
		else g.setColor(Color.white);
		g.fillRect(115, 80, 30, 30);
		
		if (!lightsOn) g.setColor(Color.magenta);
		else g.setColor(Color.white);
		g.fillRect(85, 120, 30, 40);
		
	}
	
	

}
