package lab;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TempConverter extends Applet {
	
	private Panel fPanel;
	private Panel cPanel;
	private Panel bPanel;
	
	private TextField fahrText;
	private TextField celText;
	
	public void init() {
		// Create panel
		fPanel = new Panel();
		
		// Create fLabel
		Label fahrLab = new Label("Enter Fahr Temp");
		
		// Create text field
		fahrText = new TextField(10);
		
		// Add comp to panel
		fPanel.add(fahrLab);
		fPanel.add(fahrText);
		add(fPanel);
		
		
		// Create panel
		cPanel = new Panel();
		
		// Create cLabel
		Label celLab = new Label("Celsius Temp");
		
		// Create text field
		celText = new TextField(10);
		celText.setEditable(false);
		
		// Add comp to panel
		cPanel.add(celLab);
		cPanel.add(celText);
		add(cPanel);
		
		// Create button panel
		bPanel = new Panel();
		
		// Create Button
		Button convButton = new Button("Convert");
		
		// Add action listener - When button is clicked
		convButton.addActionListener(new ButtonListener());
		
		// Add button to panel
		bPanel.add(convButton);
		add(bPanel);
		
	} // End init
	
	private class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			double ftemp, ctemp;
			ftemp = Double.parseDouble(fahrText.getText());
			ctemp = (5.0 / 9.0) * (ftemp - 32);
			
			celText.setText(String.format("%.1f", ctemp));
		}
	} // End ButtonListener class
	

} // End class
