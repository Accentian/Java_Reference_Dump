package lab;
import javax.swing.JOptionPane;


public class Addition {

	/**
	 * Addition program using JOptionPane for input and output
	 */
	public static void main(String[] args) {
		String firstNumber = JOptionPane.showInputDialog("Enter first number:");
		String secondNumber = JOptionPane.showInputDialog("Enter second number:");
		
		// convert string to integers
		int num1 = Integer.parseInt(firstNumber);
		int num2 = Integer.parseInt(secondNumber);
		
		int sum = num1 + num2;
		
		// display with showMessageDialog
		// param 1 - parentComponent: Defines the Component that is to be the parent of this dialog box. 
		//           This parameter may be null, in which case a default Frame is used as the parent, 
		//           and the dialog will be centered on the screen (depending on the L&F). 

		// param 2 - message
		// param 3 - Window title
		// param 4 - message type: style of message
		
		JOptionPane.showMessageDialog(null, "The sum is " + sum, "Addition Window", JOptionPane.PLAIN_MESSAGE);
		
		
	}

}
