package lab;

public class MTAex2 {

	public static void main(String[] args) {
		
		// Constructors
		Rectangle rect = new Rectangle(12.5, 13.5);
		System.out.println(rect.calcArea());
		System.out.println("Total area is " + rect.totalArea);
		
		Rectangle rect2 = new Rectangle();
		rect2.setLength(14.5);
		rect2.setWidth(13.2);
		System.out.println(rect2.calcArea());
		System.out.println("Total area is " + rect2.totalArea);
		
		// Switch
		int monthNum = 3;
		switch(monthNum) {
		case 1:
			System.out.println("January");
			break;
		case 2:
			System.out.println("February");
			break;
		case 3:
			System.out.println("March");
			// Value would be 4
		case 4:
			System.out.println("April");
			break;
		default:
			System.out.println("Not a month");
		} // End switch
		
		
		int[] daysOfMonth = {30, 28, 30, 30};
		for(int val: daysOfMonth) {
			System.out.println(val);
		}
		
		
		
		
		
	} // End main

} // End class

// Class with two constructors
class Rectangle {
	private double length;
	private double width;
	// If static, the area would be added together
	public double totalArea;
	
	public Rectangle(double length, double width) {
		this.length = length;
		this.width = width;
	} // End constructor
	
	public Rectangle() {
		length = 0;
		width = 0;
	} // End constructor
	
	public void setLength(double len) {
		length = len;
	}
	
	public double getLength() {
		return length;
	}
	
	public void setWidth(double wid) {
		width = wid;
	}
	
	public double getWidth() {
		return width;
	}
	
	public double calcArea() {
		totalArea += length * width;
		return length * width;
	}
	
	
} // End class Rectangle