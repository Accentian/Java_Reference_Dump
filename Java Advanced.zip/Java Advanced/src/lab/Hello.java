package lab;

import javax.swing.JApplet;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

public class Hello extends JApplet{
	
	public void init() {
		// Execute a job on event-dispatching thread
		try {
			SwingUtilities.invokeAndWait(new Runnable() {

				@Override
				public void run() {
					JLabel lbl = new JLabel("Hello world");
					add(lbl);
				}
			});
		}// End try
		
		
		catch (Exception e) {
			System.err.println("Unable to create.");
		}// End catch
		
	}// End init
	

} // End class
