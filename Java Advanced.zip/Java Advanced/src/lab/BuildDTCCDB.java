package lab;

/* K. Farley
 * 2/7/2017
 * This program creates a Students database, updates and deletes entries, and displays the final product.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class BuildDTCCDB {

	public static void main(String[] args) throws Exception
	{
		final String DB_URL = "jdbc:derby:DTCC;create=true";
		try {
			// Create a connection to database
			Connection conn = DriverManager.getConnection(DB_URL);
			//Create a Statement object
			Statement stmt = conn.createStatement();
			
			
			// Drop tables
			dropTables(conn);
			
			// Create the Students Table and insert rows of data
			createTables(conn);
	
			// Update individual records in Table
			updateTables(conn);
			
			// Delete a record from the Table
			deleteRecord(conn);
			
			// View the Table
			viewStudentsTable(conn);
			
			// Close the resources
			stmt.close();
			conn.close();
			System.out.println("Done");
			
			
		} // end try
		
		catch (Exception ex) 
		{
			System.out.println("Error: " + ex.getMessage());
		} // end catch
			
		

	} // end main
	
	public static void createTables(Connection conn) {
		try {
			Statement stmt = conn.createStatement();
			System.out.println("Creating the Students table...");
			stmt.execute("CREATE TABLE Students (Student_ID CHAR (10) NOT NULL PRIMARY KEY, LastName CHAR(20), FirstName CHAR(15), PlanOfStudy CHAR(25), GPA DOUBLE)");
			
			// insert rows
			
			String sql = "INSERT INTO Students VALUES" +
					"('899090111', 'Rothlisberger', 'Ben', 'CIT', 3.7)";
			stmt.executeUpdate(sql);
			
			sql = "INSERT INTO Students VALUES" +
					"('129020202', 'Manning', 'Peyton', 'Computer Programming', 3.8)";
			stmt.executeUpdate(sql);
			
			sql = "INSERT INTO Students VALUES" + 
					"('890101030', 'Brady', 'Tom', 'Accounting', 3.4)";
			stmt.executeUpdate(sql);
			
			sql = "INSERT INTO Students VALUES" + 
					" ('980191919', 'Rodgers', 'Aaron', 'Networking', 3.2)";
			stmt.executeUpdate(sql);
			
			sql = "INSERT INTO Students VALUES" +
					" ('807223230', 'Manning', 'Eli', 'Securities', 3.7)";
			stmt.executeUpdate(sql);
			System.out.println("Students table created.");
			
		} // end try
		
		catch (SQLException ex){
			System.out.println("ERROR: " + ex.getMessage());
		} // end catch
		
		
	} // end create Table
	
	
	public static void updateTables(Connection conn) {
		// get a Statement obj
		Statement stmt;
		try {
			stmt = conn.createStatement();
			
			// Create an update statement
			stmt.executeUpdate("UPDATE Students SET PlanOfStudy = 'Web Technologies' WHERE Student_ID = '890101030'");
			System.out.println("1 of 3 updates completed.");
				
			// Create an update statement
			stmt.executeUpdate("UPDATE Students SET GPA = 4.0 WHERE Student_ID = '807223230'");
			System.out.println("2 of 3 updates completed.");
			
			stmt.executeUpdate("UPDATE Students SET FirstName = 'Ellis' WHERE Student_ID = '807223230'");
			System.out.println("3 of 3 updates completed.");
		}
		
		catch (SQLException ex){
			System.out.println("ERROR: " + ex.getMessage());
		} // end catch
		
	} // end update method
	
	
	
	public static void deleteRecord(Connection conn) {
		Statement stmt;
		try {
			stmt = conn.createStatement();
			// Delete record
			String deleteSQLstmt = "DELETE FROM Students WHERE Student_ID = '899090111'";
			
			// Send DELETE statement to DBMS
			int rows = stmt.executeUpdate(deleteSQLstmt);
			
			// Display results
			System.out.println(rows + " row(s) were deleted.");
			
			
		} // end try
		
		catch (Exception ex) 
		{
			System.out.println("Error: " + ex.getMessage());
		} // end catch
		
		
		
		
	} // end delete method
	
	
	
	// drop table for testing purposes
	public static void dropTables(Connection conn) {
		// Get a Statement obj
		Statement stmt;
		try {
		stmt = conn.createStatement();
		
			try {
				//Drop coffee table
				stmt.execute("DROP TABLE Students");
				System.out.println("Student table dropped.");
			} // end try
		
			catch (SQLException ex){
				// No need to report an error
				// The table simply did not exist
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		
		
	} // end drop method
	
	public static void viewStudentsTable(Connection conn)
	{
		// create var for result set
		ResultSet resultset = null;

		try
		{
			// Get a Statement object.
			Statement stmt = conn.createStatement();

			// View the table.
			resultset = stmt.executeQuery("SELECT * FROM Students");

			// process results
			ResultSetMetaData metaData = resultset.getMetaData();
			
			System.out.println("Data from Students Table:");

			int numberOfColumns = metaData.getColumnCount();
			// for loop to field names
			for (int i = 1; i <= numberOfColumns; i++){
				System.out.printf("%s\t", metaData.getColumnName(i));
			}
			System.out.println();
			
			// while loop to display data
			while (resultset.next()){
				for (int i = 1; i <= numberOfColumns; i++){
					System.out.printf("%s\t", resultset.getObject(i));
				}
				System.out.println();
			}

		}
		catch (SQLException ex)
		{
			System.out.println("ERROR: " + ex.getMessage());
		}
	}	
	


} // end class