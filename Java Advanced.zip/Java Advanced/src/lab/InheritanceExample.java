package lab;

public class InheritanceExample {

	public static void main(String[] args) {
		Faculty fac1 = new Faculty();
		fac1.SetMonth(9);
		System.out.println(fac1._name + " " + fac1._empNumber + " " + fac1._title + " " + fac1._months);
		
		Staff staff1 = new Staff();
		staff1.SetType("IT Dept");
		System.out.println(staff1._type);
		
	} // End main

} // End class


// Super class Employees
class DTEmployees {
	// Instance vars
	public String _name;
	public String _empNumber;
	public String _title;
	
	// Constructor
	public DTEmployees(String name, String empNumber, String title){
		_name = name;
		_empNumber = empNumber;
		_title = title;
	}
	
} // End class DTEmployees

// Subclass Faculty
class Faculty extends DTEmployees {
	// Instance vars
	public int _months;
	
	public Faculty() {
		super("Don", "090909A", "Instructor");
		
	}
	
	public void SetMonth(int months) {
		_months = months;
	}
	
	public double CalculateRaise() {
		if(_months == 9){
			return 0.10;
		}
		else{
			return 0.12;
		}
	}
	
} // End subclass

// Subclass Staff
class Staff extends DTEmployees {
	// Declare vars
	public String _type;

	public Staff() {
		super("Susan", "08080A", "Vice President");
		
	}
	
	public void SetType(String type) {
		_type = type;
	}
	
} // End subclass
