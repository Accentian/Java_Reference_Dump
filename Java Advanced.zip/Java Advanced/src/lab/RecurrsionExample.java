package lab;

public class RecurrsionExample {

	public static void main(String[] args) {
		
		message(5);

	} // End main
	
	public static void message(int numberOfTimes) {
		System.out.println("Are we there yet?");
		
		if(numberOfTimes > 1) {
			message(numberOfTimes - 1);
		}
	}

} // End class
