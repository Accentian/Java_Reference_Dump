package lab;

public class AbstractExample {

	public static void main(String[] args) {
		Violin violin = new Violin("Red", 4);
		violin.info();
		
		Guitar guitar = new Guitar("Fender", 6);
		guitar.info();
		guitar.AdditionalInfo();
		
		
	} // End main

} // End class


// Abstract super class
abstract class Instrument {
	protected String _name;
	protected int _numberOfStrings;
	
	public Instrument(String name, int numberOfStrings){
		_name = name;
		_numberOfStrings = numberOfStrings;
	}
	
	abstract public void info(); // Method without implementation - make sure subclasses will override 
	
	public void AdditionalInfo(){
		System.out.print("More info ");
	}
	
} // End class

class Violin extends Instrument {

	public Violin(String name, int numberOfStrings) {
		super(name, numberOfStrings);
		
	}

	@Override
	public void info() {
		System.out.println("A " + _name + " has " + _numberOfStrings + " strings.");
		
	}
	
} // End subclass Violin

class Guitar extends Instrument {

	public Guitar(String name, int numberOfStrings) {
		super(name, numberOfStrings);
		
	}

	@Override
	public void info() {
		System.out.println("There are " + _numberOfStrings + " strings on a " + _name);
		
	}
	
} // End subclass Guitar