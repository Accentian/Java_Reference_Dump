package lab;
import java.util.Scanner;

/*
 * Conversion Program
 * This program will ask the user to input meters
 * After input, a menu will be displayed:
 * 1. Convert to kilometers
 * 2. Convert to inches
 * 3. Convert to feet
 * 4. Quit
 *
 * The user will select the conversion and the converted answer will be displayed.
 * The program should redisplay the menu for another selection.
 * Quit program when user selects 4.
 */

public class MetersConversion {

	public static void main(String[] args) {
		
		// Initialize variables
		int selection;
		double meters;
		double kilo;
		double inch;
		double feet;
	
		// Input the distance in Meters to be Converted
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter distance in meters:  ");
		meters = input.nextDouble();
	
		do{
			System.out.print("1.  Convert to kilometers\n");
			System.out.print("2.  Convert to inches\n");
			System.out.print("3.  Convert to feet\n");
			System.out.print("4.  Quit the program\n\r");
			
		System.out.println("Enter a selection from 1 - 4: ");
			selection = input.nextInt();
		
			if(selection == 1){
				kilo = meters * 0.001;
				System.out.println("The conversion from meters to kilometers is: " + kilo);
			}
			else if(selection == 2){	
				inch = meters * 36.37;
				System.out.println("The conversion from meters to inches is: " + inch);
			}
			else if(selection == 3){
				feet = meters * 3.201;
				System.out.println("The conversion from meters to feet is: " + feet);
			}
			else if(selection == 4){
				System.out.println("Bye!");
			}
		
		}while(selection != 4);
	}
}

