package lab;

import javax.swing.JFrame;

public class TheaterTester {

	public static void main(String[] args) {
		TheaterRevenue gui = new TheaterRevenue();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setSize(600,500);
		gui.setVisible(true);

	}

}
