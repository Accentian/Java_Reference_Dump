package lab;

import javax.swing.JFrame;

public class password
{
   public static void main( String[] args )
   {
      passwordFrame passwordFrame = new passwordFrame();
      passwordFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      passwordFrame.setSize( 225, 90 ); // set frame size
      passwordFrame.setVisible( true ); // display frame
   } // end main
} // end class password