package lab;

import java.awt.Graphics;

import javax.swing.JApplet;

public class simple extends JApplet {
	
	StringBuffer buffer;
	
	public void init() {
		buffer = new StringBuffer();
		addItem("Initializing...");
		
	}

	public void start() {
		addItem("Starting...");
		
	}
	
	public void stop() {
		addItem("Stopping...");
		
	}
	
	public void destroy() {
		addItem("Preparing to unload...");
		
	}
	
	private void addItem(String newWord) {
		System.out.println(newWord);
		buffer.append(newWord);
		repaint();
		
	} // End addItem
	
	public void paint( Graphics g) {
		// Draw a rectangle around the display area
		g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
		
		// Draw buffer in the display
		g.drawString(buffer.toString(), 5, 15);
		
	} // End paint
	
	
} // End class
