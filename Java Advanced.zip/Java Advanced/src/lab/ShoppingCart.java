package lab;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListModel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.DecimalFormat;
import java.io.*;

public class ShoppingCart extends JFrame {
	
	// Menu
	private JMenuBar menuBar;
	private JMenu fileMenu;
	private JMenuItem exitOption;
	
	// List components
	private JPanel availableBooksPanel;
	private JPanel selectedBooksPanel;
	private JPanel buttonPanel;
	private JLabel listLabels;
	private JList availableBooksList;
	private JList selectedBooksList;
	private DefaultListModel model;
	private JScrollPane selectedBooksScrollPane;
	private JScrollPane availableBooksScrollPane;
	private JButton addBook;
	private JButton removeBook;
	private JButton clearBooks;
	private JButton buyBooks;
	
	
	public ShoppingCart() {
		
		setTitle("Shopping for Books");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		buildMenu();
		buildAvailableBooksList();
		buildSelectedBooksList();
		buildButtonPanel();
		
		addPanels();
		
		pack();
		setVisible(true);
		
	} // end constructor
	
	private void buildMenu() {
		
		menuBar = new JMenuBar();
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		exitOption = new JMenuItem("Exit");
		exitOption.setMnemonic(KeyEvent.VK_X);
		exitOption.addActionListener(new ExitListener());
		
		fileMenu.add(exitOption);
		menuBar.add(fileMenu);
		
	} // end buildMenu
	
	
	private void buildAvailableBooksList() {
		
		availableBooksPanel = new JPanel();
		availableBooksList = new JList();
		
		availableBooksList.setVisibleRowCount(8);
		availableBooksScrollPane = new JScrollPane(availableBooksList);
		
		ListModel<String> books = readFileIntoListModel("/Users/jetrantham/Downloads/BookPrices.txt");
		
		availableBooksList.setModel(books);
		availableBooksPanel.add(availableBooksScrollPane);
		
		
	} // end buildAvailableBooksList
	
	private void buildSelectedBooksList() {
		
		selectedBooksPanel = new JPanel();
		model = new DefaultListModel();
		selectedBooksList = new JList(model);
		
		selectedBooksList.setVisibleRowCount(9);
		selectedBooksScrollPane = new JScrollPane(selectedBooksList);
		selectedBooksPanel.add(selectedBooksScrollPane);
		
	} // end buildSelectedBooksList
	
	private void buildButtonPanel() {
		
		buttonPanel = new JPanel();
		addBook = new JButton("Add Book");
		removeBook = new JButton("Remove Book");
		clearBooks = new JButton("Clear Selections");
		buyBooks = new JButton("Buy Books");
		
		buttonPanel.add(addBook);
		buttonPanel.add(removeBook);
		buttonPanel.add(clearBooks);
		buttonPanel.add(buyBooks);
	
		addBook.addActionListener(new AddBook());
		removeBook.addActionListener(new RemoveBook());
		clearBooks.addActionListener(new ClearBooks());
		buyBooks.addActionListener(new BuyBooks());
		
	} // end buildButtonPanel
	
	
	private void addPanels() {
		setJMenuBar(menuBar);
		listLabels = new JLabel("Available Books: \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t Selected Books: ");

		add(listLabels, BorderLayout.NORTH);
		add(availableBooksPanel, BorderLayout.WEST);
		add(selectedBooksPanel, BorderLayout.EAST);
		add(buttonPanel, BorderLayout.SOUTH);
		
	} // end addPanels
	
	
	private class ExitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
			
		}
		
	} // end ExitListener
	
	private class AddBook implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			String bookSelected = availableBooksList.getSelectedValue().toString();
			model.addElement(bookSelected);
			
		}
		
	} // end AddBook
	
	private class RemoveBook implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			int index = selectedBooksList.getSelectedIndex();
			model.removeElementAt(index);
			
		}
		
	} // end Remove Books
	
	private class ClearBooks implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			model.clear();
			
		}
		
	} // end ClearBooks
	
	private class BuyBooks implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			
			double subTotal = 0;
			
			Object[] booksPurchased = model.toArray();
			
			for (Object book : booksPurchased) {
				subTotal += Double.parseDouble(book.toString().substring(book.toString().lastIndexOf(",") + 2));
			}
			
			calculateAndDisplay(subTotal);
			
			
		}
		
	} // end BuyBooks
	
	private void calculateAndDisplay(double subTotal) {
		
		subTotal = (Math.round(subTotal * 100.0)) / 100.0;
		double tax = (Math.round((subTotal * .06) * 100.0)) / 100.0;
		double total = (Math.round((subTotal + tax) * 100.0)) / 100.0;
		
		DecimalFormat formatter = new DecimalFormat("$#0.00");
		
		String message = "The subtotal for your purchase is: " + formatter.format(subTotal) +
				". The tax for your purchase is: " + formatter.format(tax) + 
				". The grand total for your purchase is: " + formatter.format(total);
		JOptionPane.showMessageDialog(null, message);
		
	} // end calculateAndDisplay
	
	// method for reading a file into a list from: https://www.geeksforgeeks.org/different-ways-reading-text-file-java/
	private ListModel<String> readFileIntoListModel(String fileName) {
	 
	    List<String> lines = null;
	    
	    try
	    {
	    	lines = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
	    }
	 
	    catch (IOException e)
	    {
	    	e.printStackTrace();
	    }
	    
	    DefaultListModel<String> model = new DefaultListModel<>();
	    
	    for (String line : lines) {
	    	model.addElement(line);
	    }
	    
	    return model;
	    
	} // end readFileIntoList

	public static void main(String[] args) {
		new ShoppingCart();

	} // end main
 
} // end Class