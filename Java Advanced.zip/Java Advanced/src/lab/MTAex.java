package lab;

import java.util.ArrayList;
import java.util.Scanner;

public class MTAex {
	
	// 4a. Variable Scope, variable for all class 
	// 4n. Static: Don't need to create an instance
	static String jobTitle = "Instructor";

	public static void main(String[] args) {
		
		// 1. You can pass in your name or other value from the command console
		//System.out.println("Hello " + args[0] + ", welcome to Java.");
		
		// 2. Print statements
		System.out.print("Hello");
		System.out.print("World");
		System.out.print("\nGlad to see you.\n");
		System.out.print("Bye!\n");
		
		// %d is for int, %s is for String
		int x = 25, y = 10;
		System.out.printf("%d divided by %d is %d \n", x, y, x/y);
		
		
		// 3. Scanner, remember to import scanner
		Scanner input = new Scanner(System.in);
		System.out.print("Enter name: ");
		// input.next() will only print out the first word it encounters Ma Brandon -> Ma
		
		String name = input.nextLine();
		System.out.println(name);
		
		
		// 4. Variable Scope: See 4a, 4b, and 4n!!
		printTitle(); 
		
		// Or...
		// If using these two, remove static from the method below: public void printTitle
		// MTAex mta = new MTAex();
		// mta.printTitle();
		
		for (int i = 1; i <= 10; i++) {
			System.out.println(i);
		} // End for
		// Don't place the print outside
		// System.out.println(i); Causes scoping error
		
		
		// 5. Primitive data types
		// Byte: -128 to 127
		byte a = 127;
		byte b = 10;
		System.out.println(a + b);
		
		// Short: -32, 768 to 32, 767
		short p = 3299;
		short q = 12;
		System.out.println(p + q);
		
		// Long: -9, 233, 372, 036, 854, 775, 808 to -9, 233, 372, 036, 854, 775, 807
		long d = 123123123;
		
		// Float: Less precise than double
		float f = 10.123456789f;
		System.out.println(f);
		
		
		// 6. String classes
		// Comparison
		String str1 = "Hello World";
		String str2 = "Hello World";
		if (str1.equals(str2)) {
			System.out.println("They are equal");
		} // End if
		
		// Concat
		System.out.println(str1.concat(str2));
		// Length
		System.out.println("Length of str1 is: " + str1.length());
		
		
		// 7. Arrays and array list
		int[] daysOfMonth = {31,28,31,30,31,30,31,31,30,31,30,31};
		for(int index = 0; index < daysOfMonth.length; index++) {
			System.out.println("Month " + index + " has " + daysOfMonth[index] + " days");
		} // End for
		
		// Enhanced for loop for arrays
		for(int val: daysOfMonth) {
			System.out.println(val);
		}
		
		// Multi-dim arrays
		int[][] grades = {	{90, 100, 82, 98},
							{80, 100, 60},
							{88, 100, 78, 92, 100}	};
		
		// Array list, remember to import ArrayList
		ArrayList <String> colors = new ArrayList<>();
		colors.add("Blue");
		colors.add("Red");
		// Places yellow to the first place of the array
		colors.add(0, "Yellow");
		
		for(int row = 0; row < colors.size(); row++) {
			System.out.printf("%s \n", colors.get(row));
		} // End for
		
		// 8. If else if switch
		int grade = 99;
		if(grade >= 90 ) {
			System.out.println("A grade");
			// If the braces for the IF Statement is missing, it will print Good grade
			System.out.println("Good grade");
			
			// Nested IF statement
			if(grade > 95) {
				System.out.println("High marks");
			} // End nested IF
			
		} // End IF
		
		
		// Switch
		int monthNum = 3;
		// Include breaks or the program will print everything after the value
		switch(monthNum) {
		case 1:
			System.out.println("January");
			break;
			
		case 2:
			System.out.println("February");
			break;
			
		case 3:
			System.out.println("March");
			break;
			
		case 4:
			System.out.println("April");
			break;
			
		default:
			System.out.println("Hello World");
			
		} // End switch
		
		
		// 9. While and do/while
		int number = 1;
		while(number <= 5) {
			System.out.print(number);
			number++;
		} // End while
		
		number = 1;
		// If number is 10, the program will print 10
		do {
			System.out.print(number);
			number++;
		} while (number < 6);
		
		
	} // End main
	
	
	
	
	// 4b. Method for showing Variable Scope
	public static void printTitle() {
		System.out.println(jobTitle);
	} // End printTitle
	
	
	
	

} // End class
