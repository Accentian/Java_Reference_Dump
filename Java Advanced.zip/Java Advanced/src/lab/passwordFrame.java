package lab;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class passwordFrame extends JFrame 
{
   private JLabel prompt; // label to prompt user to enter data
   private JLabel display; // label to display if password is correct
   private JTextField pw; // textfield to enter password

   // constructor sets up GUI
   public passwordFrame()
   {
      super( "Password Examiner" );

      prompt = new JLabel( "Enter password:" );
      pw = new JTextField( 10 ); // textfield for password


      display = new JLabel( "Password correct/incorrect:" );

      add( prompt, BorderLayout.NORTH ); // north region
      add( pw, BorderLayout.CENTER ); // center region
      add( display, BorderLayout.SOUTH ); // south region
      
      // register anonymous action listener
      pw.addActionListener(
    		  new ActionListener() // anonymous inner class
    		  {
    			  public void actionPerformed(ActionEvent e)
    			  {

    				  String temp = pw.getText() ;
    				  if (temp.equals("password")){
    					  display.setText( "Password is correct!" );
    				  }
    				  else {
    					  display.setText( "Password is incorrect!" );
    				  }
    			  }
    		  } // end anonymous inner class
    	); // end call to addActionListener
   
      
      
   } // end ConvertFrame constructor
} // end class ConvertFrame
