package lab;

import java.util.Scanner;

public class Exponent {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a number: ");
		long number = input.nextLong();
		
		System.out.print("Enter an exponent: ");
		long exponent = input.nextLong();
		
		System.out.println("The number " + number + " with the exponent of " + exponent + " is " + exponentCalc(number, exponent));
		
	} // End main
	
	// Recursion method
	public static long exponentCalc(long number, long exponent){
		
		if(exponent == 0){
			return 1;
		}
		else{
			return number * exponentCalc(number, exponent - 1);
		}
		
		
	} // End method

} // End class
