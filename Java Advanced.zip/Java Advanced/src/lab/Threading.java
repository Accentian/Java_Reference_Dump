package lab;

public class Threading {

	public static void main(String[] args) {
		Threads R1 = new Threads("Inches");
		Threads R2 = new Threads("Centimeters");
		Threads R3 = new Threads("Yards");

		R1.start();
		R2.start();
		R3.start();

	} // End main

} // End class

class Threads implements Runnable {
	private Thread t;
	private String threadName;

	Threads(String name) {
		threadName = name;
		System.out.println("Creating thread: " + threadName);
	}

	public void start(){
		System.out.println("Starting " + threadName);
		if(t == null){
			t = new Thread(this, threadName);
			t.start();
		}
	} // End start

	@Override
	public void run() {
		System.out.println("Running thread: " + threadName);
		double result = 0.00;
		double ftToInches = 12;
		double ftToCm = 30.48;
		double ftToYards = 0.333333;

		for(double distance = 1; distance <= 100; distance++) {
			if(threadName.equals("Inches")){
				result = distance * ftToInches;
				System.out.printf(threadName + ": At %.0f feet is %.5f inches \n", distance, result);
			} // End if

			else if(threadName.equals("Centimeters")){
				result = distance * ftToCm;
				System.out.printf(threadName + ": At %.0f feet is %.5f centimeters \n", distance, result);
			} // End else if

			else if(threadName.equals("Yards")){
				result = distance * ftToYards;
				System.out.printf(threadName + ": at %.0f feet is %.5f inches \n", distance, result);
			} // End second else if

			else{
				System.out.println("An error has occured, please check threadName.");
			} // End else
		} // End For loop

		System.out.println("Thread " + threadName + " exiting");

	} // End run


} // End class
