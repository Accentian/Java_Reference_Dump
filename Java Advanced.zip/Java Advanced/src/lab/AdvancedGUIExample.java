package lab;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class AdvancedGUIExample extends JFrame{
	
	// Declare variables
	private JPanel namePanel;
	private JPanel selectedNamePanel;
	private JList nameList;
	private JTextField selectedName;
	private JLabel selectLab;
	
	// Array of string to hold names
	private String[] names = {"Bob", "Connie", "Roy", "Sarah"};
	
	////////// Combo box
	private JPanel coffeePanel;
	private JComboBox coffeeCombo;
	private String[] coffee = {"Regular", "Dark Roast", "Decaf"};
	private JTextField selectedCoffee;
	
	////////// Menu bar
	private JMenuBar menuBar;
	private JMenu fileMenu;
	private JMenuItem exitOption;
	
	// Constructor
	public AdvancedGUIExample(){
		setTitle("Advanced GUI Example");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		// Build name panel
		namePanel = new JPanel();
		nameList = new JList(names);
		nameList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		nameList.addListSelectionListener(new ListListener());
		
		// Add to panel
		namePanel.add(nameList);
		
		selectedNamePanel = new JPanel();
		selectLab = new JLabel("Selected: ");
		selectedName = new JTextField(10);
		selectedName.setEditable(false);
		
		// Add to panel
		selectedNamePanel.add(selectLab);
		selectedNamePanel.add(selectedName);
		
		////////// Combo box
		coffeePanel = new JPanel();
		coffeeCombo = new JComboBox(coffee);
		selectedCoffee = new JTextField(10);
		coffeeCombo.addActionListener(new ComboBoxListener());
		////////// Add to panel
		coffeePanel.add(coffeeCombo);
		coffeePanel.add(selectedCoffee);
		
		////////// JMenu Bar
		menuBar = new JMenuBar();
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		exitOption = new JMenuItem("Exit");
		exitOption.setMnemonic(KeyEvent.VK_X);
		exitOption.addActionListener(new ExitListener());
		////////// Add to panel
		fileMenu.add(exitOption);
		
		// Add panels to frame
		add(namePanel, BorderLayout.NORTH);
		add(selectedNamePanel, BorderLayout.CENTER);
		add(coffeePanel, BorderLayout.SOUTH);
		menuBar.add(fileMenu);
		setJMenuBar(menuBar);
		
		pack();
		setVisible(true);
		
	} // End constructor
	
	private class ListListener implements ListSelectionListener {

		@Override
		public void valueChanged(ListSelectionEvent arg0) {
			// Get name in the list
			String selection = (String) nameList.getSelectedValue();
			selectedName.setText(selection);
		}
		
	} // End class ListListener
	
	private class ComboBoxListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// Get selected coffee from combo box
			String selectionCoffee = (String) coffeeCombo.getSelectedItem();
			selectedCoffee.setText(selectionCoffee);
			
		}
		
	} // End ComboBoxListener
	
	private class ExitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			System.exit(0);
			
		}
		
	} // End ExitListener
	
	
	public static void main(String[] args){
		
		new AdvancedGUIExample();
		
	} // End main
	

} // End class
