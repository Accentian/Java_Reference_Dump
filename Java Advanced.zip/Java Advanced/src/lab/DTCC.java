package lab;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DTCC {

	public static void main(String[] args) {
		
		final String DB_URL = "jdbc:derby:DTCC;create=true";
		
		try{
			// Create connection
			Connection conn = DriverManager.getConnection(DB_URL);
			
			// If table exists
			dropTables(conn);
			
			// Build DTCC table and insert records
			buildDTCCTable(conn);
			
			// Close the connection
			conn.close();
						
			System.out.println("DB creation success!");
		}
			catch (Exception ex){
				System.out.println("ERROR: " + ex.getMessage());
		}

	} // End main
	
	public static void buildDTCCTable(Connection conn){
		try{
			Statement state = conn.createStatement();
			
			//Create table
			state.execute("CREATE TABLE DTCC (Student_ID CHAR(10) NOT NULL PRIMARY KEY, LastName CHAR(20), FirstName CHAR(15), PlanOfStudy CHAR(25), GPA Double)");
			
			// Insert row 1
			state.execute("INSERT INTO DTCC VALUES ('899090111', 'Rothlisberger', 'Ben', 'CIT', 3.7)");
			
			// Insert row 2
			state.execute("INSERT INTO DTCC VALUES ('129020202', 'Manning', 'Peyton', 'Computer Programming', 3.8)");
			
			// Insert row 3
			state.execute("INSERT INTO DTCC VALUES ('890101030', 'Brady', 'Tom', 'Accounting', 3.4)");
			
			// Insert row 4
			state.execute("INSERT INTO DTCC VALUES ('980191919', 'Rodgers', 'Aaron', 'Networking', 3.2)");
			
			// Insert row 5
			state.execute("INSERT INTO DTCC VALUES ('807223230', 'Manning', 'Eli', 'Securities', 3.7)");
			
			System.out.println("DTCC Tables created.");
			
		}
		
		catch(SQLException ex){
			System.out.println("ERROR: " + ex.getMessage());
		}
	} // End build
	
	public static void dropTables(Connection conn){
		System.out.println("Checking for existing tables...");
		
		try{
			// Get object statement
			Statement state = conn.createStatement();
			
			try{
				// Drop DTCC Table
				state.execute("DROP TABLE DTCC");
				System.out.println("DTCC table dropped.");
			}
			catch(SQLException ex){
				// No error to report, there is no table.
			}
		}
		catch(SQLException ex){
			System.out.println("ERROR: " + ex.getMessage());
			ex.printStackTrace();
		}
	} // End drop tables
	
} // End class
