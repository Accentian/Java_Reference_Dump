package lab;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.JButton;

public class TheaterRevenue extends JFrame {
	private JTextField aTicketPrice;
	private JTextField aTicketSold;
	private JTextField cTicketPrice;
	private JTextField cTicketSold;
	private JLabel lblPricePerAdult;
	private JLabel lblAmountOfAdult;
	private JLabel lblPricePerChild;
	private JLabel lblAmountOfChild;
	private JButton btnCalculate;
	private JLabel lblGrossRevenueAdult;
	private JLabel lblNetRevenueAdult;
	private JLabel lblGrossRevenueChild;
	private JLabel lblNetRevenueChild;
	private JLabel lblTotalGrossRevenue;
	private JLabel lblTotalNetRevenue;
	
	//Rate
	private double boxOffice = 0.2;
	
	public TheaterRevenue() {
		setupFrame();
	}
	
	private void setupFrame() {
		
		getContentPane().setLayout(null);
		
		lblPricePerAdult = new JLabel("Price per Adult Ticket");
		lblPricePerAdult.setBounds(69, 14, 167, 14);
		getContentPane().add(lblPricePerAdult);
		
		aTicketPrice = new JTextField();
		aTicketPrice.setBounds(270, 11, 86, 20);
		getContentPane().add(aTicketPrice);
		aTicketPrice.setColumns(10);
		
		lblAmountOfAdult = new JLabel("Amount of Adult Ticket Sold");
		lblAmountOfAdult.setBounds(69, 39, 167, 14);
		getContentPane().add(lblAmountOfAdult);
		
		aTicketSold = new JTextField();
		aTicketSold.setBounds(270, 36, 86, 20);
		getContentPane().add(aTicketSold);
		aTicketSold.setColumns(10);
		
		lblPricePerChild = new JLabel("Price per Child Ticket");
		lblPricePerChild.setBounds(69, 64, 167, 14);
		getContentPane().add(lblPricePerChild);
		
		cTicketPrice = new JTextField();
		cTicketPrice.setBounds(270, 61, 86, 20);
		getContentPane().add(cTicketPrice);
		cTicketPrice.setColumns(10);
		
		lblAmountOfChild = new JLabel("Amount of Child Ticket Sold");
		lblAmountOfChild.setBounds(69, 89, 167, 14);
		getContentPane().add(lblAmountOfChild);
		
		cTicketSold = new JTextField();
		cTicketSold.setBounds(270, 86, 86, 20);
		getContentPane().add(cTicketSold);
		cTicketSold.setColumns(10);
		
		btnCalculate = new JButton("Calculate");
		btnCalculate.setBounds(79, 114, 89, 23);
		getContentPane().add(btnCalculate);
		
		lblGrossRevenueAdult = new JLabel("Gross Revenue for adult tickets");
		lblGrossRevenueAdult.setBounds(10, 148, 257, 14);
		getContentPane().add(lblGrossRevenueAdult);
		
		lblNetRevenueAdult = new JLabel("Net Revenue for adult tickets");
		lblNetRevenueAdult.setBounds(10, 173, 257, 14);
		getContentPane().add(lblNetRevenueAdult);
		
		lblGrossRevenueChild = new JLabel("Gross Revenue for child tickets");
		lblGrossRevenueChild.setBounds(10, 198, 257, 14);
		getContentPane().add(lblGrossRevenueChild);
		
		lblNetRevenueChild = new JLabel("Net Revenue for child tickets");
		lblNetRevenueChild.setBounds(10, 223, 257, 14);
		getContentPane().add(lblNetRevenueChild);
		
		lblTotalGrossRevenue = new JLabel("Total Gross Revenue");
		lblTotalGrossRevenue.setBounds(270, 173, 217, 14);
		getContentPane().add(lblTotalGrossRevenue);
		
		lblTotalNetRevenue = new JLabel("Total Net Revenue");
		lblTotalNetRevenue.setBounds(270, 198, 217, 14);
		getContentPane().add(lblTotalNetRevenue);
		
		// Button event
		btnCalculate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String ticketPriceAdult = aTicketPrice.getText();
				String ticketSoldAdult = aTicketSold.getText();
				String ticketPriceChild = cTicketPrice.getText();
				String ticketSoldChild = cTicketSold.getText();
				
				double grossAdult = 0.00;
				double netAdult = 0.00;
				double grossChild = 0.00;
				double netChild = 0.00;
				double grossTotal = 0.00;
				double netTotal = 0.00;
				
				//Currency format
				NumberFormat formatter = new DecimalFormat("#0.00");
				
				grossAdult = Double.parseDouble(ticketPriceAdult) * Double.parseDouble(ticketSoldAdult);
				netAdult = grossAdult * boxOffice;
				
				grossChild = Double.parseDouble(ticketPriceChild) * Double.parseDouble(ticketSoldChild);
				netChild = grossChild * boxOffice;
				
				grossTotal = grossAdult + grossChild;
				netTotal = netAdult + netChild;
				
				//Display results
				lblGrossRevenueAdult.setText("Gross Revenue for adult tickets is " + formatter.format(grossAdult));
				lblNetRevenueAdult.setText("Net Revenue for adult tickets is " + formatter.format(netAdult));
				lblGrossRevenueChild.setText("Gross Revenue for child tickets is " + formatter.format(grossChild));
				lblNetRevenueChild.setText("Net Revenue for child tickets is " + formatter.format(netChild));
				lblTotalGrossRevenue.setText("Total Gross Revenue is " + formatter.format(grossTotal));
				lblTotalNetRevenue.setText("Total Net Revenue is " + formatter.format(netTotal));
			}
			
		});
	}

}
