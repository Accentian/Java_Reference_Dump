package lab;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class DTCCTableViewer {

	public static void main(String[] args) {
		
		final String DB_URL = "jdbc:derby:DTCC;create=true";
		
		try{
			// Create connection
			Connection conn = DriverManager.getConnection(DB_URL);
			
			// View data
			viewDTCC(conn);
			
			// Modify data
			modDTCC(conn);
			
			viewDTCC(conn);
			
			// Close connection
			conn.close();
		}
		catch(Exception ex){
			System.out.println("ERROR: " + ex.getMessage());
		}

	} // End main
	
	
	
	public static void viewDTCC(Connection conn){
		ResultSet resultSet = null;
		
		try{
			// Statement
			Statement state = conn.createStatement();
			
			// View table
			resultSet = state.executeQuery("SELECT * FROM DTCC");
			
			ResultSetMetaData metaData = resultSet.getMetaData();
			
			System.out.println("Data from DTCC Table:");
			
			int numberOfColumns = metaData.getColumnCount();
			
			// Loop for field names
			for (int i = 1; i <= numberOfColumns; i++){
				System.out.printf("%s\t", metaData.getColumnName(i));
			}
			System.out.println();
			
			while (resultSet.next()){
				for (int i = 1; i <= numberOfColumns; i++){
					System.out.printf("%s\t", resultSet.getObject(i));
				}
				System.out.println();
			}

		}
		catch(SQLException ex){
			System.out.println("ERROR " + ex.getMessage());
		}
		
	}
	
	
	
	public static void modDTCC(Connection conn){
		ResultSet resultSet = null;
		
		try{
			// Statement 
			Statement state = conn.createStatement();
			
			// Update the table
			state.executeUpdate("UPDATE DTCC SET PlanOfStudy = 'Web Technologies' WHERE Student_ID = '890101030'");
			state.executeUpdate("UPDATE DTCC SET FirstName = 'Ellis' WHERE Student_ID = '807223230'");
			state.executeUpdate("UPDATE DTCC SET GPA = 4.0 WHERE Student_ID = '807223230'");
			
			state.executeUpdate("DELETE FROM DTCC WHERE Student_ID = '899090111'");
			
			System.out.println("Record updated");
			
		}
		catch(SQLException ex){
			System.out.println("ERROR: " + ex.getMessage());
		}
	}

} // End class
