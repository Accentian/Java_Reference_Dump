package lab;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.JButton;

public class MonthlySalesTax extends JFrame {
	private JTextField txtSales;
	private JLabel lblEnterTheTotal;
	private JButton btnCalculate;
	private JLabel lblCountyTax;
	private JLabel lblStateTax;
	private JLabel lblTotalSalesTax;
	private JLabel lblDisplayCounty;
	private JLabel lblDisplayState;
	private JLabel lblDisplayTotal;
	
	// Tax rates
	private double COUNTY_TAX = 0.02;
	private double STATE_TAX = 0.04;
	
	public MonthlySalesTax() {
		setupFrame();
	}
	
	private void setupFrame() {
		
		getContentPane().setLayout(null);
		
		lblEnterTheTotal = new JLabel("Enter the total sales tax for this month:");
		lblEnterTheTotal.setBounds(35, 28, 256, 14);
		getContentPane().add(lblEnterTheTotal);
		
		txtSales = new JTextField();
		txtSales.setBounds(301, 25, 86, 20);
		getContentPane().add(txtSales);
		txtSales.setColumns(10);
		
		btnCalculate = new JButton("Calculate");
		btnCalculate.setBounds(163, 53, 89, 23);
		getContentPane().add(btnCalculate);
		
		lblCountyTax = new JLabel("County Tax");
		lblCountyTax.setBounds(86, 101, 97, 14);
		getContentPane().add(lblCountyTax);
		
		lblStateTax = new JLabel("State Tax");
		lblStateTax.setBounds(86, 126, 97, 14);
		getContentPane().add(lblStateTax);
		
		lblTotalSalesTax = new JLabel("Total Sales Tax");
		lblTotalSalesTax.setBounds(86, 151, 97, 14);
		getContentPane().add(lblTotalSalesTax);
		
		lblDisplayCounty = new JLabel("");
		lblDisplayCounty.setBounds(193, 101, 173, 14);
		getContentPane().add(lblDisplayCounty);
		
		lblDisplayState = new JLabel("");
		lblDisplayState.setBounds(193, 126, 173, 14);
		getContentPane().add(lblDisplayState);
		
		lblDisplayTotal = new JLabel("");
		lblDisplayTotal.setBounds(193, 151, 173, 14);
		getContentPane().add(lblDisplayTotal);
		
		// Button event
		
		btnCalculate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String taxInput = txtSales.getText();
				double showCounty = 0.00;
				double showState = 0.00;
				double showTotal = 0.00;
				
				showCounty = Double.parseDouble(taxInput) * COUNTY_TAX;
				showState = Double.parseDouble(taxInput) * STATE_TAX;
				showTotal = showCounty + showState;
				
				// Currency format
				NumberFormat formatter = new DecimalFormat("#0.00");
				
				//Display results
				lblDisplayCounty.setText("" + formatter.format(showCounty));
				lblDisplayState.setText("" + formatter.format(showState));
				lblDisplayTotal.setText("" + formatter.format(showTotal));
			}
			
		});
		
	}
}
