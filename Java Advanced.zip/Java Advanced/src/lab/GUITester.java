/*
 * Tester app for GUIExample
 */

package lab;

import javax.swing.JFrame;

public class GUITester {

	public static void main(String[] args) {
		GUIExample gui = new GUIExample();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setSize(400,400);
		gui.setVisible(true);
	} // End main

} // End class
